package testscript;

import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.text.ParseException;
import java.util.Hashtable;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.tools.ant.types.FileList.FileName;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import reports.ReportUtil;
import util.CSVoperations;
import util.TestUtil;
import datatable.Xls_Reader;
import datatable.Xls_Writer;
//testng 1
//

public class DriverScript {
	public static Xls_Reader compareCSV_C;
	public static Xls_Reader compareCSV_P;
	public static Properties CONFIG;
	public static Properties OR;
	public static Properties APPTEXT;
	public static Xls_Reader controller;
	public static Xls_Reader testData;

	public static String currentTest;
	public static String currentTestDesc;
	public static String severity;
	public static String keyword;
	public static WebDriver wbdv = null;
	public static EventFiringWebDriver driver = null;
	public static String object;
	public static String objectnxt;
	public static String currentTSID;
	public static String stepDescription;
	public static String proceedOnFail;
	public static String testStatus;
	public static String finalTestStatus;
	public static String haltTesting;
	// temp
	public static String data_column_name;
	// public static String verifyText_text;
	public static int testRepeat;
	public static int SuiteRepeat;
	public static Logger APPICATION_LOGS = Logger.getLogger("devpinoyLogger");
	public static String finalStartTime;
	public static String finalEndTime;
	public static String tdID;
	public static String tcEndTime;
	public static String tcDuration;
	public static String duration;
	public static String SuiteName = null;
	public static int tsid;

	public static FormulaEvaluator evaluator = null;

	@BeforeSuite
	public static void startTesting() {
		finalStartTime = TestUtil.now("hh:mm:ss aaa");
		// ReportUtil.startTesting("/D:/workspace/AutoPayments/test-output/final_reports/index.html",finalStartTime,
		// "Framework Design", "0.0.1");
		// /ReportUtil.startTesting("/D:/workspace/AutoPayments/test-output/final_reports/index.html",finalStartTime);
		ReportUtil.startTesting("../vnitro/VsoftReport/nitro/index.html",
				finalStartTime);
	}

	@BeforeClass
	public void initialize() throws IOException {
		// load the property fIles
		// load the config prop
		CONFIG = new Properties();
		FileInputStream fs = null;
		// FileInputStream fs = new
		// FileInputStream(System.getProperty("user.dir")+"/src/config/config.properties");
		System.out.println("config :"
				+ DriverScript.class.getResource("/config/config.properties")
						.getFile());
		fs = new FileInputStream(DriverScript.class.getResource(
				"/config/config.properties").getFile());
		CONFIG.load(fs);
		// LOAD OR
		OR = new Properties();
		// fs = new
		// FileInputStream(System.getProperty("user.dir")+"/src/config/OR.properties");
		fs = new FileInputStream(DriverScript.class.getResource(
				"/config/OR.properties").getFile());
		System.out.println("OR :"
				+ DriverScript.class.getResource("/config/OR.properties")
						.getFile());
		OR.load(fs);
		// app text prop load
		APPTEXT = new Properties();
		// fs = new
		// FileInputStream(System.getProperty("user.dir")+"/src/config/app_text.properties");
		// fs = new
		// FileInputStream(DriverScript.class.getResource("/config/app_text.properties").getFile());
		// System.out.println("app_test :"+DriverScript.class.getResource("/config/app_text.properties").getFile());
		APPTEXT.load(fs);
		/*
		 * compareCSV_P = new
		 * Xls_Reader(DriverScript.class.getResource("/CSV/csvAutomation-P.xls"
		 * ).getFile()); String
		 * fileController1=DriverScript.class.getResource("/CSV/csvAutomation-P.xls"
		 * ).getFile();
		 */
		/*
		 * compareCSV_C = new
		 * Xls_Reader(DriverScript.class.getResource("/CSV/csvAutomation-C.xls"
		 * ).getFile()); String
		 * fileController2=DriverScript.class.getResource("/CSV/csvAutomation-C.xls"
		 * ).getFile();
		 */
		// initialize datatable
		// controller= new
		// Xls_Reader(System.getProperty("user.dir")+"/src/config/Controller.xls");
		controller = new Xls_Reader(DriverScript.class.getResource(
				"/config/Controller.xls").getFile());
		String fileController = DriverScript.class.getResource(
				"/config/Controller.xls").getFile();
		System.out.println("fileController :" + fileController);
		// testData = new
		// Xls_Reader(System.getProperty("user.dir")+"/src/config/TestData.xls");

		APPICATION_LOGS.error("after initialize.......");
	}

	@SuppressWarnings("null")
	@Test
	public void testApp() throws ParseException {
		String startTime = null;
		String[] csvData = new String[11];
		String[] xlsComparisonData = new String[6];
		haltTesting = "N";
		System.out.println("before totalSuite");
		int totalSuite = controller.getSheetCount("Suite");
		System.out.println("totalSuite......." + totalSuite);

		/*// write Data to Csv

		try {
			CSVoperations.writeHeader2Csv();
		} catch (Exception e) {
			System.out.println("error in write2Csv in testapp else condition"
					+ e.getMessage());
		}*/

		// write Data to xls
		try {
			Xls_Writer.write2xlsHeader();
			System.out.println("inserting writeData2xls HEADER successful");
		} catch (Exception e) {
			System.out.println("error in write2xlsHeader in testapp else condition"
					+ e.getMessage());
		}
		for (SuiteRepeat = 1; SuiteRepeat <= totalSuite; SuiteRepeat++) {
			SuiteName = "Suite" + SuiteRepeat;
			ReportUtil.startSuite(SuiteName, totalSuite);

			for (int tcid = 2; tcid <= controller.getRowCount(SuiteName); tcid++) {

				if (haltTesting.equalsIgnoreCase("Y")) {
					break;
				}
				currentTest = controller.getCellData(SuiteName, "TCID", tcid);
				currentTestDesc = controller.getCellData(SuiteName,
						"Description", tcid);

				// initialize start time of test
				if (controller.getCellData(SuiteName, "Runmode", tcid).equals(
						"Y")) {
					// execute the keywords
					// loop again - rows in test data
					severity = controller.getCellData(SuiteName, "Severity",
							tcid);

					/*
					 * int totalSets=testData.getRowCount(currentTest); // holds
					 * total rows in test data sheet. IF sheet does not exist
					 * then 2 by default if(totalSets<=1){ totalSets=2; // run
					 * atleast once }
					 */

					// for( testRepeat=2; testRepeat<=totalSets;testRepeat++){
					// System.out.println("totalSets"+totalSets);
					// System.out.println("~~~~~~~~~~~~~~~~~TS:"+testRepeat);
					if (haltTesting.equalsIgnoreCase("Y")) {
						break;
					}
					startTime = TestUtil.now("hh:mm:ss aaa");
					finalTestStatus = "Pass";
					APPICATION_LOGS.error("~~~~~~ " + currentTest);
					// tdID=testData.getCellData(currentTest, "TDID" ,
					// testRepeat);
					// implement keyword . Reflection API
					// System.out.println(controller.getRowCount(currentTest));
					String result = null;
					for (tsid = 2; tsid <= controller.getRowCount(currentTest); tsid++) {

						tdID = controller
								.getCellData(currentTest, "TSID", tsid);
						// values from xls
						if (!(controller.getCellData(currentTest, "RunMode",
								tsid).equals("N"))) {
							keyword = controller.getCellData(currentTest,
									"Keyword", tsid);
							object = controller.getCellData(currentTest,
									"Object", tsid);
							objectnxt = controller.getCellData(currentTest,
									"Object", tsid + 1);
							currentTSID = controller.getCellData(currentTest,
									"TSID", tsid);
							stepDescription = controller.getCellData(
									currentTest, "Decription", tsid);
							proceedOnFail = controller.getCellData(currentTest,
									"ProceedOnFail", tsid);
							data_column_name = controller.getCellData(
									currentTest, "Data_Column_Name", tsid);
							// verifyText_text=controller.getCellData(currentTest,
							// "Expected_verifyText", tsid);
							haltTesting = controller.getCellData(currentTest,
									"HaltOnFail", tsid);

							System.out.println("~~~~~~~" + currentTSID
									+ "~~~~~~keyword:" + keyword
									+ "; stepDescription:" + stepDescription);

							APPICATION_LOGS.error("~~~~~~~" + currentTSID
									+ "~~~~~~keyword:" + keyword
									+ "; stepDescription:" + stepDescription);
							try {
								Method method = Keywords.class
										.getMethod(keyword);
								result = (String) method.invoke(method);
								APPICATION_LOGS
										.error("***Result of execution -- "
												+ result);
								// take screenshot - every keyword
								testStatus = result;
								String fileName = SuiteName + "_SlNo"
										+ (tcid - 1) + "_TS" + (tsid - 1) + "_"
										+ keyword + tdID + ".jpg";
								// take screenshot - on Pass TC
								// if(result.startsWith("Pass")){
								// if(CONFIG.getProperty("screenshotDisplay").equalsIgnoreCase("pass")
								// ||
								// CONFIG.getProperty("screenshotDisplay").equalsIgnoreCase("both"))
								// TestUtil.takeScreenShot(CONFIG.getProperty("screenshotPath")+fileName);
								// }
								String tsData = data_column_name;
								// String
								// tsData=testData.getCellData(currentTest,
								// data_column_name , testRepeat);
								ReportUtil.addKeyword(stepDescription, keyword,
										result, fileName, tsData);
								csvData[0] = SuiteName; // SuiteName
								csvData[1] = currentTest; // TCID
								csvData[2] = currentTestDesc; // TCDesc
								csvData[3] = severity; // TCSeverity
								csvData[4] = startTime; // TCStartTime
								csvData[5] = TestUtil.now("hh:mm:ss aaa");// TCEndTime
								csvData[6] = String.valueOf(tsid);// TSID
								csvData[7] = data_column_name; // TSTestData
								csvData[8] = stepDescription; // TDdesc
								csvData[9] = result; // TSResult
								/*try {
									CSVoperations.writeData2Csv(csvData);
									System.out
											.println("data inserted into xls successfully");
								} catch (Exception e1) {
									System.out
											.println("error in write2xls DATA in testapp if condition"
													+ e1.getMessage());
								}*/

								if (result.startsWith("Fail")) {
									finalTestStatus = "Fail";
									testStatus = result;
									// take screenshot - on Fail TC
									// String
									// fileName=SuiteName+"_TC"+(tcid-1)+"_TS"+tsid+"_"+keyword+testRepeat+".jpg";
									if (!(controller.getCellData(currentTest,
											"RunMode", tsid).equals("N"))) {
										if (CONFIG.getProperty(
												"screenshotDisplay")
												.equalsIgnoreCase("fail")
												|| CONFIG.getProperty(
														"screenshotDisplay")
														.equalsIgnoreCase(
																"both")) {
											// System.out.println("fileName......."+fileName);
											TestUtil.takeScreenShot(CONFIG
													.getProperty("screenshotPath")
													+ fileName);
											// TestUtil.takeScreenShotMySql(fileName);
											// ReportUtil.addKeyword(stepDescription,
											// keyword, result, fileName);
										}
									}

									if (proceedOnFail.equalsIgnoreCase("N")) {
										break;
									}
									if (haltTesting.equalsIgnoreCase("Y")) {
										break;
									}
								}
							} catch (Throwable t) {
								t.printStackTrace();
								APPICATION_LOGS.error("Error came");
							}

						}

					}// keywords
						// report pass or fail
					if (testStatus == null) {
						testStatus = "Pass";
					}
					APPICATION_LOGS.error("***********************************"
							+ currentTest + " --- " + testStatus);
					System.out.println("currentTest:" + currentTest);
					System.out.println("startTime:" + startTime);
					System.out.println("time:" + TestUtil.now("hh:mm:ss aaa"));
					System.out.println("testStatus:" + testStatus);
					System.out.println("finalTestStatus" + finalTestStatus);
					System.out.println("tdID:" + tdID);
					System.out.println("currentTestDesc" + currentTestDesc);
					System.out.println("severity" + severity);
					ReportUtil.addTestCase(currentTest, startTime,
							TestUtil.now("hh:mm:ss aaa"), testStatus,
							finalTestStatus, tdID, currentTestDesc, severity);
					xlsComparisonData[0] = currentTest;
					xlsComparisonData[1] = currentTestDesc;
					xlsComparisonData[2] = TestUtil.timeDifference(startTime,
							TestUtil.now("hh:mm:ss aaa"));
					xlsComparisonData[3] = severity;
					xlsComparisonData[4] = finalTestStatus;

					Xls_Writer.write2xls(xlsComparisonData);

					// }// test data
				} else {
					startTime = TestUtil.now("hh:mm:ss aaa");
					APPICATION_LOGS.error("Skipping the test " + currentTest);
					testStatus = "Skip";
					finalTestStatus = "Skip";
					tdID = "";
					// report skipped
					APPICATION_LOGS.error("***********************************"
							+ currentTest + " --- " + testStatus);

					ReportUtil.addTestCase(currentTest, startTime,
							TestUtil.now("hh:mm:ss aaa"), testStatus,
							finalTestStatus, tdID, currentTestDesc, severity);
					/*
					 * csvData[0]=SuiteName; //SuiteName csvData[1]=currentTest;
					 * //TCID csvData[2]=currentTestDesc; //TCDesc
					 * csvData[3]=testStatus; //TCStatus csvData[4]="";
					 * //TCSeverity csvData[5]=""; //TCStartTime csvData[6]="";
					 * //TCEndTime csvData[7]=""; //TSID csvData[8]=""; //TDdesc
					 * csvData[9]=""; //TSStatus csvData[10]=""; //TSTestData
					 * try { CSVoperations.writeData2Csv(csvData); } catch
					 * (Exception e) { System.out.println(
					 * "error in write2Csv in testapp else condition"
					 * +e.getMessage()); }
					 */
				}

				ReportUtil.addSystemEnvironment();
				System.out
						.println("after addSystemEnvironment ******************");
				
				System.out.println("CompareTestReports completed");
				testStatus = null;
			}

			ReportUtil.endSuite();
		}
	}

	@AfterSuite
	public static void endScript() throws ParseException {
		finalEndTime = TestUtil.now("hh:mm:ss aaa");
		duration = TestUtil.timeDifference(finalStartTime, finalEndTime);
		String endTime = TestUtil.now("hh:mm:ss aaa");
		int totalTC = 0;
		int suiteCount = controller.getSheetCount("Suite");
		for (int i = 1; i <= suiteCount; i++) {
			totalTC = totalTC + controller.getRowCount("Suite" + i) - 1;
		}
		System.out.println("Total Suites:" + suiteCount);
		System.out.println("Total TC of Suites:" + totalTC);
		ReportUtil.updateHTMLSummary(endTime, totalTC, duration,
				CONFIG.getProperty("projectTitle"),
				CONFIG.getProperty("version"), tdID,
				CONFIG.getProperty("execution_no"),
				CONFIG.getProperty("Schema"));
		System.out.println("updateHTMLSummary completed");
		ReportUtil.CompareTestReports();
		System.out.println("CompareTestReports completed");
		ReportUtil.updateComparisonReportSummary();
		//System.out.println("updateComparisonReportSummary completed");
		// ReportUtil.updateEndTime(TestUtil.now());
		// ReportUtil.updateTotalTC(controller.getRowCount("Suite1"));
		// ReportUtil.updateTotalPassTC(controller.getRowCount("Suite1"));
		// ReportUtil.updateTotalFailTC(controller.getRowCount("Suite1"));
		// ReportUtil.updateTotalSkipTC(controller.getRowCount("Suite1"));
	}
}
