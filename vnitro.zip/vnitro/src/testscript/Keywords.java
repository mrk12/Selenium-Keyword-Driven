package testscript;

//http://www.vogella.de/articles/JavaRegularExpressions/ar01s05.html
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.internal.Coordinates;
import org.openqa.selenium.internal.Locatable;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
// testng
//import org.testng.Assert;
import org.openqa.selenium.support.ui.Select;

import com.google.common.base.Function;
import com.mysql.jdbc.Driver;

public class Keywords extends DriverScript {
	public static String getVal;
	public static Map hFormula = new HashMap<String, String>();
	static String parentHandle=null;
	static String subParentHandle=null;
	
	// navigate to home url - only for first time
	public static String homeURL() {
		APPICATION_LOGS.error("Executing homeURL");
		if (wbdv == null) {
			if (CONFIG.getProperty("testBrowser").equals("Firefox")) {
				wbdv = new FirefoxDriver();
				driver = new EventFiringWebDriver(wbdv);
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			} else if (CONFIG.getProperty("testBrowser").equals("IE")) {
				System.setProperty("webdriver.ie.driver",
						CONFIG.getProperty("browserUrl"));
				DesiredCapabilities caps = DesiredCapabilities
						.internetExplorer();
				caps.setCapability("ignoreZoomSetting", true);
				wbdv = new InternetExplorerDriver(caps);
				driver = new EventFiringWebDriver(wbdv);
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			} else if (CONFIG.getProperty("testBrowser").equals("Chrome")) {
				System.setProperty("webdriver.chrome.driver",
						CONFIG.getProperty("browserUrl"));
				wbdv = new ChromeDriver();
				driver = new EventFiringWebDriver(wbdv);
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			}
			driver.manage().window().maximize();
			// else
		}
		try {
			System.out.println("login URL  ................ "
					+ OR.getProperty(object));
			driver.navigate().to(OR.getProperty(object));
			return "Pass";
		} catch (Exception e) {
			return "Fail-" + e.getMessage();
		}
	}

	public static String navigate() {
		APPICATION_LOGS.error("Executing Navigate");
		String strObj=OR.getProperty(object);
		if(strObj.isEmpty()||strObj.equals(null)){
			return "Fail - missing Object";
		}
		try { 
			driver.navigate().to(strObj);
			return "Pass";
		} catch (Exception e) {
			APPICATION_LOGS.error("Error while navigate -" + object
					+ e.getMessage());
			return "Fail-" + e.getMessage();
		}
	}

	public static String clickLink() {
		APPICATION_LOGS.error("Executing clickLink");
		String strObj=OR.getProperty(object);
		if(strObj.isEmpty()||strObj.equals(null)){
			return "Fail - missing Object";
		}
		try {
			System.out.println("link.......:" + OR.getProperty(object));
			driver.findElement(By.linkText(strObj)).click();
		} catch (Throwable t) {
			// report error
			APPICATION_LOGS.error("Error while clicking on link -" + object
					+ t.getMessage());
			return "Fail - Link Not Found";
		}
		return "Pass";
	}

	/*
	 * //verify whole text within an element public static String verifyText(){
	 * APPICATION_LOGS.error("Executing verifyText Keyword"); String
	 * expected=data_column_name; String actual = null; try{
	 * actual=driver.findElement(By.xpath(OR.getProperty(object))).getText();
	 * System.out.println("after verifyText:"+data_column_name);
	 * System.out.println("expected"+expected);
	 * System.out.println("actual"+actual); APPICATION_LOGS.error(expected);
	 * APPICATION_LOGS.error(actual); if(actual.contains(expected)){ return
	 * "Pass"; }else{ return "Fail"; } }catch(Throwable t){ // error
	 * APPICATION_LOGS.error("Error in text - "+object);
	 * APPICATION_LOGS.error("Actual - "+actual);
	 * APPICATION_LOGS.error("Expected -"+ expected); return "Fail -"+
	 * t.getMessage(); } }
	 */

	// verify partial\whole text within an element
	public static String verifyText() {
		APPICATION_LOGS.error("Executing verifyText Keyword");
		String expected = data_column_name;
		String actual = "";
		String strObj=OR.getProperty(object);
		if(strObj.isEmpty()||strObj.equals(null)){
			return "Fail - missing Object xpath";
		}
		String actualValue = driver.findElement(
				By.xpath(OR.getProperty(object))).getAttribute("value");
		String actualText = driver
				.findElement(By.xpath(strObj)).getText();
		try {
			if (actualText.isEmpty()) {
				actual = actualValue;
			} else {
				actual = actualText;
			}
			System.out.println("after actualValue:" + actualValue);
			System.out.println("after actualText:" + actualText);
			System.out.println("after expected:" + data_column_name);

			actual = actual.trim();
			expected = expected.trim();

			APPICATION_LOGS.error(expected);
			APPICATION_LOGS.error(actual);
			
			if (actual.contains(expected)) {
				// if(actual.equalsIgnoreCase(expected)){
				return "Pass";
			} else {
				return "Fail";
			}
		} catch (Throwable t) {
			// error
			APPICATION_LOGS.error("Error in verifyText - " + object);
			APPICATION_LOGS.error("Actual - " + actual);
			APPICATION_LOGS.error("Expected -" + expected);
			return "Fail -" + t.getMessage();
		}
	}

	public static String verifyDropText() {
		APPICATION_LOGS.error("Executing verifyDropText Keyword");
		String data = data_column_name;
		String strObj=OR.getProperty(object);
		if(strObj.isEmpty()||strObj.equals(null)){
			return "Fail - missing Object xpath";
		}
		try {
			new Select(driver.findElement(By.xpath(strObj)))
					.selectByVisibleText(data);
			Select DropdownList = new Select(
					driver.findElement(By.xpath(strObj)));
			// java.util.List<WebElement> allSelectedOptions =
			// DropdownList.getAllSelectedOptions();
			WebElement firstSelectedOption = DropdownList
					.getFirstSelectedOption();
			// System.out.println("verify selected text::"+firstSelectedOption.getText());
			if (data.equals(firstSelectedOption.getText())) {
				return "Pass";
			} else {
				return "Fail";
			}

		} catch (Throwable t) {
			// report error
			APPICATION_LOGS.error("Error in verifyDropText -" + object
					+ t.getMessage());
			return "Fail - " + t.getMessage();
		}
	}

	// verify parital\whole text in an page
	public static String verifyPageSrc() {
		APPICATION_LOGS.error("Executing verifyPage Keyword");
		String expected = data_column_name;
		boolean verifyVal = false;
		try {
			verifyVal = driver.getPageSource().contains(expected);
			System.out.println("verifyVal : " + verifyVal);
			if (verifyVal == true) {
				return "Pass";
			} else {
				return "Fail";
			}
		} catch (Throwable t) {
			// error
			APPICATION_LOGS.error("Error in verifyPageSrc - " + object);
			APPICATION_LOGS.error("Expected -" + expected);
			return "Fail -" + t.getMessage();
		}
	}

	/*
	 * public static String inputByKeys(){
	 * 
	 * APPICATION_LOGS.error("Executing input Keyword"); // extract the test
	 * data String data =data_column_name ; //String data
	 * =testData.getCellData(currentTest, data_column_name , testRepeat); try{
	 * driver.findElement(By.xpath(OR.getProperty(object))).sendKeys(data);
	 * }catch(Throwable t){ // report error
	 * APPICATION_LOGS.error("Error while writing into input -"+ object +
	 * t.getMessage()); return "Fail - "+t.getMessage(); } return "Pass"; }
	 */

	public static String input() {

		APPICATION_LOGS.error("Executing clearAndInput Keyword");
		// extract the test data
		String data = data_column_name;
		// String data =testData.getCellData(currentTest, data_column_name ,
		// testRepeat);
		String strObj=OR.getProperty(object);
		if(strObj.isEmpty()||strObj.equals(null)){
			return "Fail - missing Object xpath";
		}
		try {
			driver.findElement(By.xpath(strObj)).clear();
			driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
			driver.findElement(By.xpath(strObj)).sendKeys(data);
		} catch (Throwable t) {
			// report error
			APPICATION_LOGS.error("Error while writing into input -" + object
					+ t.getMessage());
			return "Fail - " + t.getMessage();
		}
		return "Pass";
	}

	public static String clear() {

		APPICATION_LOGS.error("Executing clear Keyword");
		// extract the test data
		String data = data_column_name;
		// String data =testData.getCellData(currentTest, data_column_name ,
		// testRepeat);
		String strXpath = OR.getProperty(object);
		if(strXpath.isEmpty()||strXpath.equals(null)){
			return "Fail - missing Object xpath";
		}
		try {
		
			driver.findElement(By.xpath(strXpath)).clear();
		} catch (Throwable t) {
			// report error
			APPICATION_LOGS.error("Error while writing into clear -" + object
					+ t.getMessage());
			return "Fail - " + t.getMessage();
		}
		return "Pass";
	}

	public static String clickButton() {
		APPICATION_LOGS.error("Executing clickButton Keyword");
		try {
			driver.findElement(By.xpath(OR.getProperty(object))).click();
		} catch (Throwable t) {
			// report error
			APPICATION_LOGS.error("Error while clicking on Button -" + object
					+ t.getMessage());
			return "Fail - " + t.getMessage();
		}
		return "Pass";
	}

	public static String clickButtonName() {
		APPICATION_LOGS.error("Executing clickButton Keyword");
		try {
			driver.findElement(By.name(OR.getProperty(object))).click();
		} catch (Throwable t) {
			// report error
			APPICATION_LOGS.error("Error while clicking on Button -" + object
					+ t.getMessage());
			return "Fail - " + t.getMessage();
		}
		return "Pass";
	}

	/*
	 * public static String selectByKeys(){
	 * APPICATION_LOGS.error("Executing selectByKeys Keyword"); // extract the
	 * test data String data =data_column_name ;
	 * System.out.println("data"+data); //String data
	 * =testData.getCellData(currentTest, data_column_name , testRepeat); try{
	 * driver.findElement(By.xpath(OR.getProperty(object))).sendKeys(data);
	 * 
	 * }catch(Throwable t){ // report error
	 * APPICATION_LOGS.error("Error while selectByKeys from droplist -"+ object
	 * + t.getMessage()); return "Fail - "+t.getMessage(); } return "Pass"; }
	 * 
	 * public static String selectByOptions(){
	 * APPICATION_LOGS.error("Executing select Keyword"); // extract the test
	 * data String data =data_column_name ; System.out.println("data"+data);
	 * //String data =testData.getCellData(currentTest, data_column_name ,
	 * testRepeat); try{
	 * driver.findElement(By.xpath(OR.getProperty(object))).click();
	 * driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	 * By.tagName("select"); WebElement select =
	 * driver.findElement(By.xpath(OR.getProperty(object))); List<WebElement>
	 * allOptions = select.findElements(By.tagName("option"));
	 * 
	 * for (WebElement option : allOptions) {
	 * //System.out.println(String.format("Value is: %s", option.getText()));
	 * System.out.println("select data : "+data.toString());
	 * System.out.println("select option.getText(): "+option.getText());
	 * option.click(); if(option.getText().equals(data.toString())){
	 * option.submit(); break; } } }catch(Throwable t){ // report error
	 * APPICATION_LOGS.error("Error while Selecting from droplist -"+ object +
	 * t.getMessage()); return "Fail - "+t.getMessage(); } return "Pass"; }
	 * 
	 * public static String selectByValue(){
	 * APPICATION_LOGS.error("Executing selectByValue Keyword"); final
	 * List<WebElement> radios = driver.findElements(By.name("enabled")); try{
	 * for (WebElement radio : radios) { if
	 * (radio.getText().equals(OR.getProperty(object))) { radio.click(); } }
	 * }catch(Throwable t){ // report error
	 * APPICATION_LOGS.error("Error while selectByValue-"+ object +
	 * t.getMessage()); return "Fail - "+t.getMessage(); } return "Pass"; }
	 * 
	 * public static String selectByValue() {
	 * APPICATION_LOGS.error("Executing selectByValue Keyword"); String data
	 * =data_column_name ; try{ Select selectBox = new
	 * Select(driver.findElement(By.xpath(OR.getProperty(object))));
	 * selectBox.selectByValue(data); }catch(Throwable t){ // report error
	 * APPICATION_LOGS.error("Error while selectByValue from droplist -"+ object
	 * + t.getMessage()); return "Fail - "+t.getMessage(); } return "Pass"; }
	 */

	public static String select() {
		APPICATION_LOGS.error("Executing select Keyword");
		String data = data_column_name;
		String strXpath = OR.getProperty(object);
		if(strXpath.isEmpty()||strXpath.equals(null)){
			return "Fail - missing Object xpath";
		}
		try {
			Select selectBox = new Select(driver.findElement(By.xpath(strXpath)));
			selectBox.selectByVisibleText(data);
		} catch (Throwable t) {
			// report error
			APPICATION_LOGS.error("Error while Executing select Keyword -"
					+ object + t.getMessage());
			return "Fail - " + t.getMessage();
		}
		return "Pass";
	}

	/*
	 * public static String focus() {
	 * APPICATION_LOGS.error("Executing focus Keyword"); try{ WebElement
	 * element=driver.findElement(By.xpath(OR.getProperty(object)));
	 * if("input".equals(element.getTagName())){ element.sendKeys(""); } else{
	 * new Actions(driver).moveToElement(element).perform(); } }catch(Throwable
	 * t){ return "Fail - "+t.getMessage(); } return "Pass"; }
	 */

	public static String clickCheckBox() {
		APPICATION_LOGS.error("Executing clickCheckBox Keyword");
		String strXpath = OR.getProperty(object);
		if(strXpath.isEmpty()||strXpath.equals(null)){
			return "Fail - missing Object xpath";
		}
		try {
			driver.findElement(By.xpath(strXpath)).click();
		} catch (Throwable t) {
			// report error
			APPICATION_LOGS.error("Error while clicking on checkbox -" + object
					+ t.getMessage());
			return "Fail - " + t.getMessage();
		}
		return "Pass";
	}

	/*
	 * public static String radioByValue(){
	 * APPICATION_LOGS.error("Executing radioByValue Keyword"); final
	 * List<WebElement> radios = driver.findElements(By.name("enabled")); try{
	 * for (WebElement radio : radios) { if
	 * (radio.getText().equals(OR.getProperty(object))) { radio.click(); } }
	 * }catch(Throwable t){ // report error
	 * APPICATION_LOGS.error("Error while radioByValue-"+ object +
	 * t.getMessage()); return "Fail - "+t.getMessage(); } return "Pass"; }
	 */
	public static String radioByValue() {
		APPICATION_LOGS.error("Executing radioByValue Keyword");
		String data = data_column_name;
		String strXpath = OR.getProperty(object);
		if(strXpath.isEmpty()||strXpath.equals(null)){
			return "Fail - missing Object xpath";
		}
		final List<WebElement> radios = driver.findElements(By.xpath(strXpath));
		try {
			for (WebElement radio : radios) {
				if (radio.getText().equals(data)) {
					radio.click();
				}
			}
		} catch (Throwable t) {
			// report error
			APPICATION_LOGS.error("Error while radioByValue-" + object
					+ t.getMessage());
			return "Fail - " + t.getMessage();
		}
		return "Pass";
	}

	public static String Wait() throws NumberFormatException,
			InterruptedException {
		APPICATION_LOGS.error("Executing wait Keyword");
		// extract the test data
		String data = data_column_name;
		// String data =testData.getCellData(currentTest, data_column_name ,
		// testRepeat);
		// DecimalFormat df=new DecimalFormat("#");
		// Thread.sleep(Long.parseLong(df.format(Double.parseDouble(data))));
		if (data.contains(".")) {
			double d = Double.parseDouble(data);
			long l = (new Double(d)).longValue();
			TimeUnit.SECONDS.sleep(l);
		} else {
			TimeUnit.SECONDS.sleep(Long.parseLong(data));
		}
		return "Pass";
	}

	public static String wWait() throws NumberFormatException,
			InterruptedException {
		APPICATION_LOGS.error("Executing AutoWait Keyword");

		WebDriverWait wait = new WebDriverWait(driver, 100);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(OR
				.getProperty(objectnxt))));

		return "Pass";
	}

	public static String AutoWait() throws NumberFormatException,
			InterruptedException {
		APPICATION_LOGS.error("Executing wait Keyword");
		// extract the test data
		String data = data_column_name;
		// String data =testData.getCellData(currentTest, data_column_name ,
		// testRepeat);
		DecimalFormat df = new DecimalFormat("#");
		driver.manage()
				.timeouts()
				.implicitlyWait(
						Long.parseLong(df.format(Double.parseDouble(data))),
						TimeUnit.SECONDS);
		return "Pass";
	}

	public static String vWait() throws NumberFormatException,
			InterruptedException {
		APPICATION_LOGS.error("Executing wait Keyword");
		WebElement foundElement = new WebDriverWait(driver, 30)
				.until(ExpectedConditions.visibilityOfElementLocated(By
						.xpath(OR.getProperty(objectnxt))));
		return "Pass";
	}

	public static String cWait() throws NumberFormatException,
			InterruptedException {
		APPICATION_LOGS.error("Executing wait Keyword");
		WebElement foundElement = new WebDriverWait(driver, 30)
				.until(ExpectedConditions.elementToBeClickable(By.xpath(OR
						.getProperty(objectnxt))));
		return "Pass";
	}

	public static String clickAlertOk() {
		APPICATION_LOGS.error("Executing clickAlertOk Keyword");
		// String data =testData.getCellData(currentTest, data_column_name ,
		// testRepeat);
		try {
			driver.switchTo().alert().accept();
		} catch (Throwable t) {
			// report error
			APPICATION_LOGS.error("Error while clicking on Alert Ok Button -"
					+ object + t.getMessage());
			return "Fail - " + t.getMessage();
		}
		return "Pass";
	}

	public static String clickAlertCancel() {
		APPICATION_LOGS.error("Executing clickAlertCancel Keyword");
		// String data =testData.getCellData(currentTest, data_column_name ,
		// testRepeat);
		try {
			driver.switchTo().alert().dismiss();
		} catch (Throwable t) {
			// report error
			APPICATION_LOGS
					.error("Error while clicking on Alert Cancel Button -"
							+ object + t.getMessage());
			return "Fail - " + t.getMessage();
		}
		return "Pass";
	}
	
	/*public static String switchToWindow() {
		APPICATION_LOGS.error("Executing switchToWindow Keyword");
		System.out.println("Inside switchToWindow");
		parentHandle = driver.getWindowHandle();
		System.out.println("parentHandle : "+parentHandle);
		if(driver.getWindowHandles().size() != 1){
			for (String winHandle : driver.getWindowHandles()) {
				System.out.println("childHandles : "+winHandle);
				if(!parentHandle.equals(winHandle)){
					driver.switchTo().window(winHandle);
					return "Pass";
				}
			}
		}
		 //driver.close();
		 //driver.switchTo().window(parentHandle);
		// driver.close();
		return "Fail";
	}
	*/
	
	public static String switchToWindow() {
		APPICATION_LOGS.error("Executing switchToWindow Keyword");
		int cntHandles=1;
		System.out.println("Inside switchToWindow");
		parentHandle = driver.getWindowHandle();
		System.out.println("parentHandle1 : "+parentHandle);
			for (String winHandle : driver.getWindowHandles()) {
				System.out.println("cntHandles :"+cntHandles);
				System.out.println("driver.getWindowHandles().size() :"+driver.getWindowHandles().size());
					if(driver.getWindowHandles().size()==cntHandles){
						System.out.println("childHandles1 : "+winHandle);
						driver.switchTo().window(winHandle);
						return "Pass";
					}
					cntHandles++;	
			}
		return "Fail";
	}
	
	public static String switchToParentWindow(){
        try {
            //String winHandleBefore = driver.getWindowHandle();
            System.out.println("parentHandle : "+parentHandle);
            driver.close(); 
            //Switch back to original browser (first window)
            driver.switchTo().window(parentHandle);
            //continue with original browser (first window)
        }catch(Exception e){
        	APPICATION_LOGS.error("Unable to Switch to parent window" + e.getMessage());
        	return "Fail";
        }
        return "Pass";
    }
	
	public static String switchToSubParentWindow(){
        try {
            //String winHandleBefore = driver.getWindowHandle();
            System.out.println("subParentHandle : "+subParentHandle);
            driver.close(); 
            //Switch back to original browser (first window)
            driver.switchTo().window(subParentHandle);
            //continue with original browser (first window)
        }catch(Exception e){
        	APPICATION_LOGS.error("Unable to Switch to subParentHandle" + e.getMessage());
        	return "Fail";
        }
        return "Pass";
    }
	
	public static String switchToFrame() {
		APPICATION_LOGS.error("Executing switchToChildFrame Keyword");
		String data = data_column_name;
		// String data =testData.getCellData(currentTest, data_column_name ,
		// testRepeat);
		try {
			driver.switchTo().frame(data);
		} catch (Throwable t) {
			// report error
			APPICATION_LOGS.error("Error in switchToChildFrame -" + object
					+ t.getMessage());
			return "Fail - " + t.getMessage();
		}
		return "Pass";
	}

	public static String switchToFrameById() {
		APPICATION_LOGS.error("Executing switchToFrameById Keyword");
		String data = data_column_name;
		// String data =testData.getCellData(currentTest, data_column_name ,
		// testRepeat);
		try {
			driver.switchTo().frame(driver.findElement(By.id(data)));
		} catch (Throwable t) {
			// report error
			APPICATION_LOGS.error("Error in switchToFrameById -" + object
					+ t.getMessage());
			return "Fail - " + t.getMessage();
		}
		return "Pass";
	}
	
	
	public static String switchToParentFrame() {
		APPICATION_LOGS.error("Executing switchToParentFrame Keyword");
		try {
			driver.switchTo().defaultContent();
		} catch (Throwable t) {
			// report error
			APPICATION_LOGS.error("Error in switchToParentFrame -" + object
					+ t.getMessage());
			return "Fail - " + t.getMessage();
		}
		return "Pass";
	}

	public static String verifyLength() {
		APPICATION_LOGS.error("Executing verifyLength Keyword");
		String data = data_column_name;
		String strXpath = OR.getProperty(object);
		if(strXpath.isEmpty()||strXpath.equals(null)){
			return "Fail - missing Object xpath";
		}
		try {
			String strVal = driver
					.findElement(By.xpath(strXpath))
					.getAttribute("value");
			System.out.println("entered string : " + strVal);
			int length = strVal.length();
			System.out.println("input getlength : " + length);
			System.out.println("data length : " + Integer.parseInt(data));
			if (length <= Integer.parseInt(data)) {
				return "Pass";
			} else {
				return "Fail";
			}
		} catch (Throwable t) {
			// report error
			APPICATION_LOGS.error("Error in verifyLength -" + object
					+ t.getMessage());
			return "Fail - " + t.getMessage();
		}
	}

	public static String browserClose() {
		APPICATION_LOGS.error("Executing windowClose Keyword");
		try {
			driver.close();
		} catch (Throwable t) {
			// report error
			APPICATION_LOGS.error("Error in windowClose -" + object
					+ t.getMessage());
			return "Fail - " + t.getMessage();
		}
		return "Pass";
	}

	public static String browserQuit() {
		APPICATION_LOGS.error("Executing browserQuit Keyword");
		try {
			driver.quit();
		} catch (Throwable t) {
			// report error
			APPICATION_LOGS.error("Error in browserQuit -" + object
					+ t.getMessage());
			return "Fail - " + t.getMessage();
		}
		return "Pass";
	}

	public static String browserMaximize() {
		APPICATION_LOGS.error("Executing windowMaximize Keyword");
		try {
			driver.manage().window().maximize();
		} catch (Throwable t) {
			// report error
			APPICATION_LOGS.error("Error in windowMaximize -" + object
					+ t.getMessage());
			return "Fail - " + t.getMessage();
		}
		return "Pass";
	}

	public static String refreshPage() {
		APPICATION_LOGS.error("Executing refreshPage");
		try {

			((JavascriptExecutor) driver)
					.executeScript("document.location.reload()");
			Thread.sleep(2000);
		} catch (Exception t) {
			APPICATION_LOGS.error("Error in refreshPage -" + object
					+ t.getMessage());
			return "Fail - " + t.getMessage();
		}
		return "Pass";
	}

	public static String refresh() {
		APPICATION_LOGS.error("Executing refreshPage");
		try {

			driver.navigate().refresh();
		} catch (Exception t) {
			APPICATION_LOGS.error("Error in refresh -" + object
					+ t.getMessage());
			return "Fail - " + t.getMessage();
		}
		return "Pass";
	}

	public static String dtpInput() {
		APPICATION_LOGS.error("Executing dtpInput keyword");
		Hashtable<String, String> dtpmonths = new Hashtable<String, String>();
		dtpmonths.put("01", "January");
		dtpmonths.put("02", "February");
		dtpmonths.put("03", "March");
		dtpmonths.put("04", "April");
		dtpmonths.put("05", "May");
		dtpmonths.put("06", "June");
		dtpmonths.put("07", "July");
		dtpmonths.put("08", "August");
		dtpmonths.put("09", "September");
		dtpmonths.put("10", "October");
		dtpmonths.put("11", "November");
		dtpmonths.put("12", "December");

		// extract the test data
		String data = data_column_name;
		System.out.println("in dtp : " + data_column_name);
		// String data=testData.getCellData(currentTest, data_column_name ,
		// testRepeat);
		String datasplit[] = data.split("/");
		int dtpdayInt = Integer.parseInt(datasplit[1]);
		String dtpdayStr = String.valueOf(dtpdayInt);
		/*
		 * System.out.println("month : "+datasplit[0]);
		 * System.out.println("year : "+datasplit[2]);
		 * System.out.println("day : "+dtpdayStr);
		 */
		String strXpath = OR.getProperty(object);
		if(strXpath.isEmpty()||strXpath.equals(null)){
			return "Fail - missing Object xpath";
		}
		try {
			driver.findElement(By.xpath(strXpath)).click();
			TimeUnit.SECONDS.sleep(2);
			// driver.switchTo().activeElement();

			for (String winHandle : driver.getWindowHandles()) {
				driver.switchTo().window(winHandle);
				if (driver.getTitle().equals("Calendar")) {
					System.out.println("You are in date picker window month : "
							+ dtpmonths.get(datasplit[0]));
					// System.out.println("....month");
					driver.findElement(By.xpath("//*[@name='Month']"))
							.sendKeys(dtpmonths.get(datasplit[0]));
					break;
				} /*
				 * else{ System.out.println(
				 * "Month : Title of the page after - switchingTo: " +
				 * driver.getTitle()); }
				 */
			}

			TimeUnit.SECONDS.sleep(2);
			for (String winHandle : driver.getWindowHandles()) {
				driver.switchTo().window(winHandle);
				if (driver.getTitle().equals("Calendar")) {
					System.out.println("You are in date picker window year : "
							+ datasplit[2]);
					// System.out.println("....year");
					driver.findElement(By.xpath("//*[@name='Year']")).sendKeys(
							datasplit[2]);
					break;
				} /*
				 * else{ System.out.println(
				 * "Year : Title of the page after - switchingTo: " +
				 * driver.getTitle()); }
				 */
			}

			TimeUnit.SECONDS.sleep(2);
			for (String winHandle : driver.getWindowHandles()) {
				driver.switchTo().window(winHandle);
				if (driver.getTitle().equals("Calendar")) {
					System.out.println("You are in date picker window day : "
							+ dtpdayStr);
					// System.out.println("....year");
					driver.findElement(By.linkText(dtpdayStr)).click();
					break;
				} /*
				 * else{ System.out.println(
				 * "Year : Title of the page after - switchingTo: " +
				 * driver.getTitle()); }
				 */
			}

		} catch (Throwable t) {
			// report error
			APPICATION_LOGS.error("Error while writing into dtpInput -"
					+ object + t.getMessage());
			return "Fail - " + t.getMessage();
		}
		return "Pass";
	}

	public static String getVal() {
		APPICATION_LOGS.error("Executing getVal keyword");
		String data = data_column_name;
		int startIndex = 0;
		int endIndex = 0;
		String strValue = "";
		String strXpath = OR.getProperty(object);
		if(strXpath.isEmpty()||strXpath.equals(null)){
			return "Fail - missing Object xpath";
		}
		try {
			// getVal=driver.findElement(By.xpath(OR.getProperty(object))).getAttribute("value");
			strValue = driver.findElement(By.xpath(strXpath))
					.getText();
			System.out.println("strValue : " + strValue);
			if (data.equalsIgnoreCase("")) {
				getVal = strValue;
				System.out.println("whole String : " + getVal);
				APPICATION_LOGS.error("whole String : " + getVal);
			} else if (data.contains(",")) { // checks substring from given x,y
												// of actual data
				String datasplit[] = data.split(",");
				startIndex = Integer.parseInt(datasplit[0]);
				endIndex = Integer.parseInt(datasplit[1]);
				getVal = strValue.substring(startIndex, endIndex).trim();
				System.out.println("subString : " + getVal);
				APPICATION_LOGS.error("subString : " + getVal);
			} else { // checks substring from 'x' till the last of the actual
						// data
				startIndex = Integer.parseInt(data);
				getVal = strValue.substring(startIndex).trim();
				System.out.println("String till end: " + getVal);
				APPICATION_LOGS.error("String till end: " + getVal);
			}
		} catch (Exception t) {
			APPICATION_LOGS.error("Error in getVal keyword -" + object
					+ t.getMessage());
			return "Fail - " + t.getMessage();
		}
		return "Pass";
	}

	public static String setVal() {
		APPICATION_LOGS.error("Executing setVal keyword");
		String strXpath = OR.getProperty(object);
		if(strXpath.isEmpty()||strXpath.equals(null)){
			return "Fail - missing Object xpath";
		}
		try {
			System.out.println("setVal : " + getVal);
			driver.findElement(By.xpath(strXpath)).sendKeys(getVal);

		} catch (Exception t) {
			APPICATION_LOGS.error("Error in setVal keyword -" + object
					+ t.getMessage());
			return "Fail - " + t.getMessage();
		}
		return "Pass";
	}

	public static String setValList() {
		APPICATION_LOGS.error("Executing setValList keyword");
		String strXpath = OR.getProperty(object);
		if(strXpath.isEmpty()||strXpath.equals(null)){
			return "Fail - missing Object xpath";
		}
		try {
			System.out.println("setVal setValList: " + getVal);
			//driver.findElement(By.xpath(strXpath)).sendKeys(getVal);
			Select selectBox = new Select(driver.findElement(By.xpath(strXpath)));
			selectBox.selectByVisibleText(getVal);

		} catch (Exception t) {
			APPICATION_LOGS.error("Error in setVal keyword -" + object
					+ t.getMessage());
			return "Fail - " + t.getMessage();
		}
		return "Pass";
	}

	public static String setValSubList() {
		APPICATION_LOGS.error("Executing setValList keyword");
		String strXpath = OR.getProperty(object);
		if(strXpath.isEmpty()||strXpath.equals(null)){
			return "Fail - missing Object xpath";
		}
		try {
			System.out.println("setVal setValSubList: " + getVal);
			//driver.findElement(By.xpath(strXpath)).sendKeys(getVal);
			
			Select selectBox = new Select(driver.findElement(By.xpath(strXpath)));
			List<WebElement> slctOptions= selectBox.getOptions();
			int cntIndex=0;
			String temptext=null;
			String tempOptions=null;
			//System.out.println("slctOptions size : "+slctOptions.size());
			for (WebElement temp : slctOptions) {
				temptext=temp.getText();
				//System.out.println("Inside slctOptions : "+temptext);
				if(temptext.contains(":")){
					tempOptions=temptext.substring(0,temptext.indexOf(":")).trim();
					System.out.println("getText" + temptext + "getSubText" +tempOptions);
		            if(tempOptions.equals(getVal)){
		            	//System.out.println("cntIndex : "+cntIndex);
		            	selectBox.selectByIndex(cntIndex);
		            	return "Pass";
		            }		                
				}else if(temptext.contains("-")){
					tempOptions=temptext.substring(0,temptext.indexOf("-")).trim();
					System.out.println("getText" + temptext + "getSubText" +tempOptions);
		            if(tempOptions.equals(getVal)){
		            	//System.out.println("cntIndex : "+cntIndex);
		            	selectBox.selectByIndex(cntIndex);
		            	return "Pass";
		            }		                
				}
				
				//System.out.println("end of slctOptions");
	            cntIndex++;
	            
	        }
			return "Fail";
		} catch (Exception t) {
			APPICATION_LOGS.error("Error in setVal keyword -" + object
					+ t.getMessage());
			return "Fail - " + t.getMessage();
		}
		
	}
	
	public static String top2left() {
		APPICATION_LOGS.error("Executing top2left Keyword");
		try {
			driver.switchTo().defaultContent();
			driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
			driver.switchTo().frame("middle");
			driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
			driver.switchTo().frame("left");
		} catch (Throwable t) {
			// report error
			APPICATION_LOGS.error("Error in top2left -" + t.getMessage());
			return "Fail - " + t.getMessage();
		}
		return "Pass";
	}

	public static String top2right() {
		APPICATION_LOGS.error("Executing top2right Keyword");
		String data = data_column_name;
		try {
			driver.switchTo().defaultContent();
			driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
			driver.switchTo().frame("middle");
			driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
			driver.switchTo().frame("right");
		} catch (Throwable t) {
			// report error
			APPICATION_LOGS.error("Error in top2right -" + t.getMessage());
			return "Fail - " + t.getMessage();
		}
		return "Pass";
	}

	public static String go2top() {
		APPICATION_LOGS.error("Executing go2top Keyword");
		String data = data_column_name;
		try {
			driver.switchTo().defaultContent();
			driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
			driver.switchTo().defaultContent();
			driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
			driver.switchTo().frame("left");
		} catch (Throwable t) {
			// report error
			APPICATION_LOGS
					.error("Error in go2top -" + object + t.getMessage());
			return "Fail - " + t.getMessage();
		}
		return "Pass";
	}

	public static String left2right() {
		APPICATION_LOGS.error("Executing left2right Keyword");
		String data = data_column_name;
		try {
			driver.switchTo().defaultContent();
			driver.switchTo().defaultContent();
			driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
			driver.switchTo().defaultContent();
			driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
			driver.switchTo().frame("middle");
			driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
			driver.switchTo().frame("right");
		} catch (Throwable t) {
			// report error
			APPICATION_LOGS.error("Error in left2right -" + object
					+ t.getMessage());
			return "Fail - " + t.getMessage();
		}
		return "Pass";
	}

	public static String right2left() {
		APPICATION_LOGS.error("Executing right2left Keyword");
		String data = data_column_name;
		try {
			driver.switchTo().defaultContent();
			driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
			driver.switchTo().frame("left");
		} catch (Throwable t) {
			// report error
			APPICATION_LOGS.error("Error in right2left -" + t.getMessage());
			return "Fail - " + t.getMessage();
		}
		return "Pass";
	}

	/*
	 * public static String clickList(){
	 * 
	 * APPICATION_LOGS.error("Executing clickList Keyword"); String data
	 * =data_column_name ; try{ List<WebElement> allLi =
	 * driver.findElements(By.tagName("li")); for(WebElement eachLi:allLi){
	 * String tmp = eachLi.getText(); //System.out.println("Text in li: "+tmp);
	 * if(tmp.equals(data)){ //System.out.println("eachLi:"+eachLi);
	 * eachLi.findElement(By.linkText(data)).click(); break; } }
	 * }catch(Throwable t){ // report error
	 * APPICATION_LOGS.error("Error in right2left -"+ object + t.getMessage());
	 * return "Fail - "+t.getMessage(); } return "Pass"; }
	 */

	public static String clickList() {
		APPICATION_LOGS.error("Executing clickList Keyword");
		String data = data_column_name;
		String strXpath = OR.getProperty(object);
		if(strXpath.isEmpty()||strXpath.equals(null)){
			return "Fail - missing Object xpath";
		}
		try {
			List<WebElement> allLi = driver.findElements(By.xpath(strXpath)
					.tagName("li"));
			for (WebElement eachLi : allLi) {
				String tmpLi = eachLi.getText();
				// System.out.println("Text in li: "+tmp);
				if (tmpLi.equals(data)) {
					// System.out.println("eachLi:"+eachLi);
					eachLi.findElement(By.linkText(data)).click();
					break;
				}
			}
		} catch (Throwable t) {
			// report error
			APPICATION_LOGS.error("Error in clickList -" + object
					+ t.getMessage());
			return "Fail - " + t.getMessage();
		}
		return "Pass";
	}

	public static String clickDisplayList() {
		APPICATION_LOGS.error("Executing clickDisplayList Keyword");
		String data = getVal.trim();
		System.out.println("get value:" + getVal);
		String strXpath = OR.getProperty(object);
		if(strXpath.isEmpty()||strXpath.equals(null)){
			return "Fail - missing Object xpath";
		}
		try {
			List<WebElement> allLi = driver.findElements(By.xpath(strXpath)
					.tagName("li"));
			for (WebElement eachLi : allLi) {
				String tmpLi = eachLi.getText().trim();
				System.out.println("Text in li: " + tmpLi);
				System.out.println("get value:" + data);
				if (tmpLi.equals(data)) {
					System.out.println("eachLi:" + eachLi);
					eachLi.findElement(By.linkText(data)).click();
					break;
				}
			}
		} catch (Throwable t) {
			// report error
			APPICATION_LOGS.error("Error in clickDisplayList -" + object
					+ t.getMessage());
			return "Fail - " + t.getMessage();
		}
		return "Pass";
	}

	public static String isEnabled() {
		APPICATION_LOGS.error("Executing isEnabled Keyword");
		String strXpath = OR.getProperty(object);
		if(strXpath.isEmpty()||strXpath.equals(null)){
			return "Fail - missing Object xpath";
		}
		try {
			WebElement objTest = driver.findElement(By.xpath(strXpath));
			// System.out.println("objTest.isEnabled()"+objTest.isEnabled());
			if (objTest.isEnabled()) {
				return "Pass";
			} else {
				return "Fail";
			}
		} catch (Throwable t) {
			// report error
			APPICATION_LOGS.error("Error in isEnabled -" + object
					+ t.getMessage());
			return "Fail - " + t.getMessage();
		}
	}

	public static String isDisabled() {
		String strXpath = OR.getProperty(object);
		if(strXpath.isEmpty()||strXpath.equals(null)){
			return "Fail - missing Object xpath";
		}
		APPICATION_LOGS.error("Executing isDisabled Keyword OBJ : " + strXpath);
		System.out.println("inside isDisabled");
		try {
			System.out.println("before isDisabled");
			WebElement objTest = driver.findElement(By.xpath(strXpath));
			System.out.println("after isDisabled" + strXpath);
			System.out.println("after objTest.isEnabled()"
					+ objTest.isEnabled());
			APPICATION_LOGS.error("after objTest.isEnabled()"
					+ objTest.isEnabled());
			if (objTest.isEnabled()) {
				return "Fail";
			} else {
				return "Pass";
			}
		} catch (Throwable t) {
			// report error
			APPICATION_LOGS.error("Error in isDisabled -" + object
					+ t.getMessage());
			return "Fail - " + t.getMessage();
		}
	}

	public static String dtpCore() {
		APPICATION_LOGS.error("Executing dtpCore Keyword");
		String strXpath = OR.getProperty(object);
		if(strXpath.isEmpty()||strXpath.equals(null)){
			return "Fail - missing Object xpath";
		}
		String data = data_column_name;
		String datasplit[] = data.split("/");
		int dtpdayInt = Integer.parseInt(datasplit[1]);
		int dtpMonthInt = Integer.parseInt(datasplit[0]);
		int dtpYearInt = Integer.parseInt(datasplit[2]);
		String dtpdayStr = String.valueOf(dtpdayInt);
		try {
			WebElement element = driver.findElement(By.id(strXpath));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", element);
		} catch (Throwable t) {
			// report error
			APPICATION_LOGS.error("Error in dtpCore -" + object
					+ t.getMessage());
			return "Fail - " + t.getMessage();
		}
		return "Pass";
	}

	public static String scrollBottom() {
		APPICATION_LOGS.error("Executing scrollBottom Keyword");
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("window.scrollTo(0,Math.max(document.documentElement.scrollHeight,document.body.scrollHeight,document.documentElement.clientHeight)-200);");
		return "Pass";
	}

	public static String scrollTop() {
		APPICATION_LOGS.error("Executing scrollTop Keyword");
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("window.scrollTo(0,Math.min(document.documentElement.scrollHeight,document.body.scrollHeight,document.documentElement.clientHeight));");
		return "Pass";
	}

	public static String scrollElement() {
		APPICATION_LOGS.error("Executing scrollElement Keyword");
		String strXpath = OR.getProperty(object);
		if(strXpath.isEmpty()||strXpath.equals(null)){
			return "Fail - missing Object xpath";
		}
		try {
			WebElement element = driver.findElement(By.xpath(strXpath));
			Coordinates coordinate = ((Locatable) element).getCoordinates();
			coordinate.onPage().y = coordinate.onPage().y - 200;
			coordinate.inViewPort().y = coordinate.inViewPort().y - 200;
		} catch (Throwable t) {
			// report error
			APPICATION_LOGS.error("Error in scrollElement -" + object
					+ t.getMessage());
			return "Fail - " + t.getMessage();
		}
		return "Pass";
	}

	public static String getFormulaVar() {
		APPICATION_LOGS.error("Executing getFormulaVar Keyword");
		String strXpath = OR.getProperty(object);
		if(strXpath.isEmpty()||strXpath.equals(null)){
			return "Fail - missing Object xpath";
		}
		String data = data_column_name;
		int startIndex = 0;
		int endIndex = 0;
		String strValue = "";
		try {
			strValue = driver.findElement(By.xpath(OR.getProperty(object)))
					.getAttribute("value");
			if (strValue.isEmpty() || strValue.equals("")) {
				strValue = driver.findElement(By.xpath(OR.getProperty(object)))
						.getText();
			}
			System.out.println("strValue : " + strValue);
			hFormula.put(data, strValue);
		} catch (Throwable t) {
			// report error
			APPICATION_LOGS.error("Error in getFormulaVar -" + object
					+ t.getMessage());
			return "Fail - " + t.getMessage();
		}
		return "Pass";
	}

	public static String verifyFormula() {
		APPICATION_LOGS.error("Executing verifyFormula Keyword");
		String expected = data_column_name;
		String strXpath = OR.getProperty(object);
		if(strXpath.isEmpty()||strXpath.equals(null)){
			return "Fail - missing Object xpath";
		}
		String actual = "";
		String actualValue = driver
				.findElement(By.xpath(strXpath))
				.getAttribute("value").trim();
		String actualText = driver
				.findElement(By.xpath(strXpath)).getText().trim();

		try {
			if (actualText.isEmpty()) {
				actual = actualValue;
			} else {
				actual = actualText;
			}
			expected = expected.trim();

			Iterator<Map.Entry<String, String>> iterator = hFormula.entrySet()
					.iterator();
			while (iterator.hasNext()) {
				Map.Entry<String, String> hmapEntries = iterator.next();
				expected = expected.replace(hmapEntries.getKey(),
						hmapEntries.getValue());
			}

			ScriptEngineManager mgr = new ScriptEngineManager();
			ScriptEngine engine = mgr.getEngineByName("JavaScript");
			System.out.println("Formula :: " + expected);
			System.out.println("expected result $" + engine.eval(expected));
			double expectedOutput = Double.parseDouble(engine.eval(expected)
					.toString());
			double actualOutput = Double.parseDouble(actual);

			APPICATION_LOGS.error(expected);
			APPICATION_LOGS.error(actual);

			if (actualOutput == expectedOutput) {
				return "Pass";
			} else {
				return "Fail";
			}
		} catch (Throwable t) {
			// error
			APPICATION_LOGS.error("Error in verifyFormula - " + object);
			APPICATION_LOGS.error("Actual - " + actual);
			APPICATION_LOGS.error("Expected -" + expected);
			// return "Fail -"+ t.getMessage();
		}
		return "Pass";
	}

	public static String clearFormula() {
		APPICATION_LOGS.error("Executing clearFormula Keyword");
		hFormula.clear();
		return "Pass";
	}

	public static String inputCalcDate() {
		APPICATION_LOGS.error("Executing inputcustomDate Keyword");
		String target = OR.getProperty(object);
		if(target.isEmpty()||target.equals(null)){
			return "Fail - missing Object xpath";
		}
		String[] actual;
		String[] source = data_column_name.split(",");// m,d,y no. of times to
														// increment/decrement
		String sourceValue = driver
				.findElement(By.xpath(OR.getProperty(source[3])))
				.getAttribute("value").trim();
		String sourceText = driver
				.findElement(By.xpath(OR.getProperty(source[3]))).getText()
				.trim();

		try {
			if (sourceText.isEmpty()) {
				actual = sourceValue.split("/");
			} else {
				actual = sourceText.split("/");
			}
			// System.out.println("(expected[1])"+(Integer.parseInt(source[1])));//day
			// System.out.println("(expected[0])"+(Integer.parseInt(source[0])));//month
			// System.out.println("(expected[2])"+(Integer.parseInt(source[2])));//year
			// System.out.println("(expected[3])"+(Integer.parseInt(source[3])));//source

			int cyear = Integer.parseInt(actual[2]) - 1;
			// System.out.println("cyear"+cyear);
			int cmonth = Integer.parseInt(actual[0]) - 1;
			// System.out.println("cmonth"+cmonth);
			int cday = Integer.parseInt(actual[1]);
			// System.out.println("cday"+cday);

			Calendar calendar = new GregorianCalendar();
			calendar.set(cyear, cmonth, cday);
			System.out.println("cDate before ~ " + calendar.getTime());
			// calendar.setTime(cDate);
			calendar.add(Calendar.DATE, Integer.parseInt(source[1]));
			calendar.add(Calendar.MONTH, Integer.parseInt(source[0]));
			calendar.add(Calendar.YEAR, Integer.parseInt(source[2]));
			SimpleDateFormat format1 = new SimpleDateFormat("MM/dd/yyyy");
			String formatted = format1.format(calendar.getTime());
			System.out.println("calculated" + formatted);
			System.out.println("target ~ " + target);
			driver.findElement(By.xpath(target)).clear();
			driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
			driver.findElement(By.xpath(target)).sendKeys(formatted);
			System.out.println("cDate after ~ " + calendar.getTime());
		} catch (Throwable t) {
			// report error
			APPICATION_LOGS.error("Error in inputcustomDate -" + object
					+ t.getMessage());
			return "Fail - " + t.getMessage();
		}
		return "Pass";
	}

	public static String countElements() {
		APPICATION_LOGS.error("Executing countElements Keyword");
		List<WebElement> items = driver.findElements(By.xpath("*"));		
		return "Pass";
	}
	
	public static String verifyCalcDate() {
		APPICATION_LOGS.error("Executing verifyCalcDate Keyword");
		String target = OR.getProperty(object);
		if(target.isEmpty()||target.equals(null)){
			return "Fail - missing Object xpath";
		}
		String[] actual;
		String[] source = data_column_name.split(",");// m,d,y no. of times to
														// increment/decrement
		String sourceValue = driver
				.findElement(By.xpath(OR.getProperty(source[3])))
				.getAttribute("value").trim();
		String sourceText = driver
				.findElement(By.xpath(OR.getProperty(source[3]))).getText()
				.trim();

		try {
			if (sourceText.isEmpty()) {
				actual = sourceValue.split("/");
			} else {
				actual = sourceText.split("/");
			}
			// System.out.println("(expected[1])"+(Integer.parseInt(source[1])));//day
			// System.out.println("(expected[0])"+(Integer.parseInt(source[0])));//month
			// System.out.println("(expected[2])"+(Integer.parseInt(source[2])));//year
			// System.out.println("(expected[3])"+(Integer.parseInt(source[3])));//source

			int cyear = Integer.parseInt(actual[2]) - 1;
			// System.out.println("cyear"+cyear);
			int cmonth = Integer.parseInt(actual[0]) - 1;
			// System.out.println("cmonth"+cmonth);
			int cday = Integer.parseInt(actual[1]);
			// System.out.println("cday"+cday);

			Calendar calendar = new GregorianCalendar();
			calendar.set(cyear, cmonth, cday);
			System.out.println("cDate before ~ " + calendar.getTime());
			// calendar.setTime(cDate);
			calendar.add(Calendar.DATE, Integer.parseInt(source[1]));
			calendar.add(Calendar.MONTH, Integer.parseInt(source[0]));
			calendar.add(Calendar.YEAR, Integer.parseInt(source[2]));
			SimpleDateFormat format1 = new SimpleDateFormat("MM/dd/yyyy");
			String formatted = format1.format(calendar.getTime());
			String targetValue = driver.findElement(By.xpath(OR.getProperty(object))).getText();
			System.out.println("Expected ~" + formatted);
			System.out.println("Actual ~ " + targetValue);
			if(targetValue.equals(formatted)){
				return "Pass";
			}
			else{
				return "Fail";
			}
		} catch (Throwable t) {
			// report error
			APPICATION_LOGS.error("Error in verifyCalcDate -" + object
					+ t.getMessage());
			return "Fail - " + t.getMessage();
		}
	}

	public static String searchElements() {
		APPICATION_LOGS.error("Executing searchElements Keyword");
		List<WebElement> links = driver.findElements(By.xpath("//html/body/form/table/tbody/tr[2]/td/table/tbody/tr[3]/td[1]/div/a"));
		for (WebElement link: links) {
		  //link.click();
			System.out.println("GL : "+link);
		}		
		return "Pass";
	}
	
	public static String getPageTitle() {
		APPICATION_LOGS.error("Executing getPageTitle Keyword");
		System.out.println("Title : "+driver.getTitle());
		System.out.println("win Handle : "+driver.getWindowHandle());
		return "Pass";
	}
	
	public static String selectGl() {
		APPICATION_LOGS.error("Executing selectGl Keyword");
		//String glAcNo = data_column_name;
		String xpath_full = OR.getProperty(data_column_name);
		//String xpathGL_start="//html/body/form/table/tbody/tr[2]/td/table/tbody/tr[";
		//String xpathGL_end="]/td[1]/div/a";
		driver.findElement(By.xpath(OR.getProperty(object))).click();
		String parentHandle = driver.getWindowHandle();
		//System.out.println("parentHandle : "+parentHandle);
		for (String winHandle : driver.getWindowHandles()) {
			//System.out.println("childHandles : "+winHandle);
			if(!parentHandle.equals(winHandle))
				driver.switchTo().window(winHandle); 
		}
		//String xpath_full=xpathGL_start+glAcNo+xpathGL_end;
		driver.findElement(By.xpath(xpath_full)).click();
		driver.switchTo().window(parentHandle);
		return "Pass";
	}
	
	/*
	 * public static void addMonths(Date date, int numMonths){
	 * date.setMonth((date.getMonth() + numMonths)); } public static void
	 * addDays(Date date, int numDays){ date.setMonth((date.getMonth() - 1 +
	 * numDays) % 12 + 1); } public static void addYears(Date date, int
	 * numYears){ date.setMonth((date.getMonth() - 1 + numYears) % 12 + 1); }
	 */
}
