package datatable;

import java.io.File;
import java.io.FileOutputStream;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;

import testscript.DriverScript;

//import statements
public class Xls_Writer {
	public static String csvPath;
	public static String lOutputFileName;
	// Blank workbook
	static HSSFWorkbook workbook = new HSSFWorkbook();

	// Create a blank sheet
	static HSSFSheet sheet = workbook.createSheet("ComparisonReport");

	// This data needs to be written (Object[])
	static Map<String, Object[]> data = new TreeMap<String, Object[]>();

	public static void write2xlsHeader() {
		DriverScript DrvScript = new DriverScript();
		String csvPath = DrvScript.CONFIG.getProperty("indexReport");
		csvPath = DrvScript.CONFIG.getProperty("indexReport");
		csvPath = csvPath.substring(0, csvPath.lastIndexOf("/"));
		csvPath = csvPath.substring(0, csvPath.lastIndexOf("/"));
		
		lOutputFileName = csvPath + "/CSV/csvAutomation-C.xls";
		
		data.put("1", new Object[] {"TCID", "DESCRIPTION", "DURATION","SEVERITY","STATUS"});
		// Iterate over data and write to sheet
		Set<String> keyset = data.keySet();
		int rownum = 0;
		System.out.println("rownum : "+rownum);
		for (String key : keyset) {
			HSSFRow row = sheet.createRow(rownum++);
			Object[] objArr = data.get(key);
			int cellnum = 0;
			for (Object obj : objArr) {
				HSSFCell cell = row.createCell(cellnum++);
				if (obj instanceof String)
					cell.setCellValue((String) obj);
				else if (obj instanceof Integer)
					cell.setCellValue((Integer) obj);
			}
		}
		
		try {
			// Write the workbook in file system
			FileOutputStream out = new FileOutputStream(new File(
					lOutputFileName));
			workbook.write(out);
			out.close();
			System.out.println("csvAutomation-C.xls created successfully.");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	

	public static void write2xls(String[] xlsData) {
		DriverScript DrvScript = new DriverScript();
		data.put("1", xlsData);
		
		/*data.put("2", xlsData[1]);
		data.put("3", xlsData[2]);
		data.put("4", xlsData[3]);
		data.put("5", xlsData[4]);
		data.put("6", xlsData[5]);
		data.put("7", xlsData[6]);
		data.put("8", xlsData[7]);
		data.put("9", xlsData[8]);
		data.put("10", xlsData[0]);*/
		
		System.out.println("xlsData : "+xlsData);
		// Iterate over data and write to sheet
		Set<String> keyset = data.keySet();
		int rownum = sheet.getPhysicalNumberOfRows();
		for (String key : keyset) {
			HSSFRow row = sheet.createRow(rownum++);
			Object[] objArr = data.get(key);
			int cellnum = 0;
			for (Object obj : objArr) {
				HSSFCell cell = row.createCell(cellnum++);
				if (obj instanceof String)
					cell.setCellValue((String) obj);
				else if (obj instanceof Integer)
					cell.setCellValue((Integer) obj);
			}
		}
		String csvPath = DrvScript.CONFIG.getProperty("indexReport");
		csvPath = DrvScript.CONFIG.getProperty("indexReport");
		csvPath = csvPath.substring(0, csvPath.lastIndexOf("/"));
		csvPath = csvPath.substring(0, csvPath.lastIndexOf("/"));
		lOutputFileName = csvPath + "/CSV/csvAutomation-C.xls";
		try {
			// Write the workbook in file system
			FileOutputStream out = new FileOutputStream(new File(
					lOutputFileName));
			workbook.write(out);
			out.close();
			System.out.println("csvAutomation-C.xls created successfully.");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	/*public static void write2xls(String[] xlsData) {
		DriverScript DrvScript = new DriverScript();
		String csvPath = DrvScript.CONFIG.getProperty("indexReport");
		csvPath = csvPath.substring(0, csvPath.lastIndexOf("/"));
		csvPath = DrvScript.CONFIG.getProperty("indexReport");
		csvPath = csvPath.substring(0, csvPath.lastIndexOf("/"));
		lOutputFileName = csvPath + "/CSV/csvAutomation-C.xls";

		File lFile = new File(lOutputFileName);
		HSSFWorkbook lWorkBook = null;
		HSSFSheet lWorkSheet = null;
		FileOutputStream lFout = null;
		POIFSFileSystem lPOIfs = null;

		if (lFile.exists()) {
			try {
				lFout = new FileOutputStream(lOutputFileName, true);
				lWorkBook = new HSSFWorkbook(lPOIfs);
				lWorkSheet = lWorkBook.getSheet("ComparisonReport");
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else {
			// Create new file
			try {
				lFout = new FileOutputStream(lOutputFileName);
			} catch (Exception e) {
				e.printStackTrace();
			}
			lWorkBook = new HSSFWorkbook();
			lWorkSheet = lWorkBook.createSheet("ComparisonReport");
		}

		try {
			for (String lValue : xlsData) {

				if (lValue == null) {
					System.out.println("=>NULL VALUE => " + lValue);
				} else {
					StringBuffer lSqlLine = new StringBuffer(lValue);

					HSSFRow lRow = lWorkSheet.createRow(lWorkSheet
							.getLastRowNum() + 1);

					System.out.println("lWorkSheet.getLastRowNum() "
							+ lWorkSheet.getLastRowNum());

					HSSFCell lCell = lRow.createCell((short) 0);
					lCell.setCellValue(lValue);
					System.out.println(lValue);
				}
			}
			lWorkBook.write(lFout);
			lFout.flush();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				lFout.close();
			} catch (Exception e) {
				e.printStackTrace();
			}

		}
	}*/
}
