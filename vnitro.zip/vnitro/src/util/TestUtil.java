package util;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import testscript.DriverScript;

public class TestUtil extends DriverScript {

	// returns current date and time
	public static String now(String dateFormat) {
		Calendar cal = Calendar.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);
		return sdf.format(cal.getTime());
	}

	public static String timeDifference(String startTime, String endTime) {
		System.out.println("startTime : "+startTime);
		Date finalEndTime = null;
		Date finalStartTime = null;
		try {
			finalEndTime = new SimpleDateFormat("hh:mm:ss", Locale.US)
					.parse(endTime);
			finalStartTime = new SimpleDateFormat("hh:mm:ss", Locale.US)
					.parse(startTime);
		} catch (ParseException e) {

			e.printStackTrace();
		}
		long diff = Math.abs(finalEndTime.getTime() - finalStartTime.getTime());
		long diffSeconds = diff / 1000 % 60;
		long diffMinutes = diff / (60 * 1000) % 60;
		long diffHours = diff / (60 * 60 * 1000) % 24;
		// long diffDays = diff / (24 * 60 * 60 * 1000);

		// String strDays=diffDays + " days, ";
		String strHours = String.valueOf(diffHours) + ":";
		String strMin = String.valueOf(diffMinutes) + ":";
		String strSec = String.valueOf(diffSeconds);
		String duration = strHours + strMin + strSec;
		// System.out.print(duration + " duration");
		return duration;
	}
	
	public static String timeAddition(String time1, String time2)
			throws ParseException {
		System.out.println("time1 : "+time1);
		DateFormat format = new SimpleDateFormat("HH:mm:ss");  

		Date currentTime = format.parse(time1);
		Date previousTime = format.parse(time2);  

		long diff = Math.abs(currentTime.getTime() - previousTime.getTime());
		System.out.println("diff"+diff);
		
		String strDiff=convertSecondsToHMmSs(diff);
		return String.valueOf(strDiff);
	}
	
	public static String timeIncDec(String time1, String time2)
			throws ParseException {
		DateFormat format = new SimpleDateFormat("HH:mm:ss");  

		Date currentTime = format.parse(time1);
		Date previousTime = format.parse(time2); 
		
		long diff = currentTime.getTime() - previousTime.getTime();

		if(diff>0){
			return "Decrease";
		}else if(diff<0){
			return "Increase";
		}else{
			return "nil";
		}
	}
	
	public static String convertSecondsToHMmSs(long milliseconds) {
	    long s = (milliseconds/1000) % 60;
	    long m = ((milliseconds/1000) / 60) % 60;
	    long h = ((milliseconds/1000) / (60 * 60)) % 24;
	    return String.format("%d:%02d:%02d", h,m,s);
	}
	
	public static Integer convertTimeToSeconds(String duration) {
		System.out.println("in convertTimeToSeconds....");
		System.out.println("duration :" + duration);
		String[] time = duration.split(":");
		System.out.println("time1 :" + time[0]);
		System.out.println("time2 :" + time[1]);
		System.out.println("time3 :" + time[2]);
		Integer intSeconds = Integer.parseInt(time[2]);
		Integer intMinutes = Integer.parseInt(time[1]) / 60;
		Integer intHours = Integer.parseInt(time[0]) / 3600;
		Integer totalSeconds = intSeconds + intMinutes + intHours;
		System.out.println("duration :" + duration + " totalSeconds : "
				+ totalSeconds);
		return totalSeconds;

	}

	public static boolean checkFileExists(String filepath) {
		File f = new File(filepath);
		if (f.exists())
			return true;
		else
			return false;
	}

	// store screenshots in Physical Location
	public static void takeScreenShot(String filePath) {
		File scrFile = ((TakesScreenshot) driver)
				.getScreenshotAs(OutputType.FILE);
		try {
			FileUtils.copyFile(scrFile, new File(filePath));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	// // store screenshots in MySql
	// public static void takeScreenShotMySql(String fileName) {
	// FnScreenShot fss=new FnScreenShot();
	// try {
	// File scrFile =
	// ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
	// //System.out.println("inside takeScreenShotMySql------>"+scrFile);
	// fss.ScnInsert(scrFile,fileName);
	// } catch (Exception e) {
	//
	// e.printStackTrace();
	// }
	// }

	// make zip of reports
	public static void zip(String filepath) {
		try {
			File inFolder = new File(filepath);
			File outFolder = new File("Reports.zip");
			ZipOutputStream out = new ZipOutputStream(new BufferedOutputStream(
					new FileOutputStream(outFolder)));
			BufferedInputStream in = null;
			byte[] data = new byte[1000];
			String files[] = inFolder.list();
			for (int i = 0; i < files.length; i++) {
				in = new BufferedInputStream(new FileInputStream(
						inFolder.getPath() + "/" + files[i]), 1000);
				out.putNextEntry(new ZipEntry(files[i]));
				int count;
				while ((count = in.read(data, 0, 1000)) != -1) {
					out.write(data, 0, count);
				}
				out.closeEntry();
			}
			out.flush();
			out.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
