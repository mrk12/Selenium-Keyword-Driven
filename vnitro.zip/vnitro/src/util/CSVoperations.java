package util;

import testscript.DriverScript;

import java.io.FileReader;
import java.io.FileWriter;
import java.util.HashMap;
import java.util.Map;

import org.supercsv.cellprocessor.Optional;
/*import java.util.Calendar;
import java.util.GregorianCalendar;
import org.apache.xmlbeans.impl.xb.xmlconfig.ConfigDocument.Config;
import org.supercsv.cellprocessor.FmtBool;
import org.supercsv.cellprocessor.FmtDate;
import org.supercsv.cellprocessor.constraint.LMinMax;*/
import org.supercsv.cellprocessor.constraint.NotNull;
import org.supercsv.cellprocessor.constraint.UniqueHashCode;
import org.supercsv.cellprocessor.ift.CellProcessor;
import org.supercsv.io.CsvMapReader;
import org.supercsv.io.CsvMapWriter;
import org.supercsv.io.ICsvMapReader;
import org.supercsv.io.ICsvMapWriter;
import org.supercsv.prefs.CsvPreference;

public class CSVoperations {
	final static String[] header = new String[] {"Suite", "TCID", "TCDesc", "TCSeverity", "TCStartTime", "TCEndTime", "TSID", "TSTestData", "TSDesc", "TSResult"};
	public static String csvPath;
	
	public static void writeHeader2Csv() throws Exception {
		
        DriverScript DrvScript = new DriverScript();
        // create the customer Maps (using the header elements for the column keys)
        final Map<String, Object> testcaseheader = new HashMap<String, Object>();
        
        String csvPath=DrvScript.CONFIG.getProperty("indexReport");
        csvPath = csvPath.substring(0,csvPath.lastIndexOf("/"));
        System.out.println("csvPath....:"+csvPath);
        ICsvMapWriter mapWriter = null;
        try {
                mapWriter = new CsvMapWriter(new FileWriter(csvPath+"/CSV/csvAutomation.csv"),
                        CsvPreference.STANDARD_PREFERENCE);
                final CellProcessor[] processors = getProcessors();
                // write the header
                mapWriter.writeHeader(header);                
        }
        finally {
                if( mapWriter != null ) {
                        mapWriter.close();
                }
        }
	}
	
	@SuppressWarnings("unused")
	public static void writeData2Csv(String[] csvData) throws Exception {
        DriverScript DrvScript = new DriverScript();
        //for(int i=0;i<=10;i++)
        //	System.out.println("csvData["+i+"] : "+csvData[i]);
        // create the customer Maps (using the header elements for the column keys)
        final Map<String, Object> testcaseheader = new HashMap<String, Object>();
        testcaseheader.put(header[0], csvData[0].toString());
        testcaseheader.put(header[1], csvData[1].toString());
        testcaseheader.put(header[2], csvData[2].toString());
        testcaseheader.put(header[3], csvData[3].toString());
        testcaseheader.put(header[4], csvData[4].toString());
        testcaseheader.put(header[5], csvData[5].toString());
        testcaseheader.put(header[6], csvData[6].toString());
        testcaseheader.put(header[7], csvData[7].toString());
        testcaseheader.put(header[8], csvData[8].toString());
        testcaseheader.put(header[9], csvData[9].toString());
        
        /* testcaseheader.put(header[0], "1");
        testcaseheader.put(header[1], "testcaseheader");
        testcaseheader.put(header[2], "Dunbar");
        testcaseheader.put(header[3], new GregorianCalendar(1945, Calendar.JUNE, 13).getTime());
        testcaseheader.put(header[4], "1600 Amphitheatre Parkway\nMountain View, CA 94043\nUnited States");
        testcaseheader.put(header[5], null);
        testcaseheader.put(header[6], null);
        testcaseheader.put(header[7], "\"May the Force be with you.\" - Star Wars");
        testcaseheader.put(header[8], "jdunbar@gmail.com");
        testcaseheader.put(header[9], 0L);*/
        
        csvPath=DrvScript.CONFIG.getProperty("indexReport");
        csvPath = csvPath.substring(0,csvPath.lastIndexOf("/"));
        //System.out.println("csvPath....:"+csvPath);
        ICsvMapWriter mapWriter = null;
        try {
                mapWriter = new CsvMapWriter(new FileWriter(csvPath+"/CSV/csvAutomation.csv",true),
                        CsvPreference.STANDARD_PREFERENCE);
            
                final CellProcessor[] processors = getProcessors();
            
                // write the header
                //mapWriter.writeHeader(header);
                
                // write the customer maps
                mapWriter.write(testcaseheader, header, processors);
            
        }
        finally {
            	//System.out.println("csv creation - one test step inserted. TCID:"+csvData[1].toString()+" , TSID:"+csvData[6].toString());
                if( mapWriter != null ) {
                        mapWriter.close();
                }
        }
	}
	
	private static CellProcessor[] getProcessors() {
        
        final CellProcessor[] processors = new CellProcessor[] {
                /*new UniqueHashCode(), // customerNo (must be unique)
                new NotNull(), // firstName
                new NotNull(), // lastName
                new FmtDate("dd/MM/yyyy"), // birthDate
                new NotNull(), // mailingAddress
                new Optional(new FmtBool("Y", "N")), // married
                new Optional(), // numberOfKids
                new NotNull(), // favouriteQuote
                new NotNull(), // email
                new LMinMax(0L, LMinMax.MAX_LONG) // loyaltyPoints
                */
                new UniqueHashCode(), // SuiteName
                new NotNull(), // TCID
                new NotNull(), // TCDesc
                new Optional(), // TCSeverity
                new NotNull(), // TCStartTime
                new NotNull(), // TCEndtime
                new NotNull(), // TSID
                new NotNull(), // TSDesc
                new NotNull(), // TSResult
                new Optional() // TCTestData
        };
        return processors;
	}
	
	private static void readCsv() throws Exception {
	        
	        ICsvMapReader mapReader = null;
	        try {
	                mapReader = new CsvMapReader(new FileReader(csvPath+"/CSV/csvAutomation.csv"),
	                        CsvPreference.STANDARD_PREFERENCE);
	                
	                // the header columns are used as the keys to the Map
	                final String[] header = mapReader.getHeader(true);
	                final CellProcessor[] processors = getProcessors();
	                
	                Map<String, Object> customerMap;
	                while( (customerMap = mapReader.read(header, processors)) != null ) {
	                        System.out.println(String.format("lineNo=%s, rowNo=%s, customerMap=%s", mapReader.getLineNumber(),
	                                mapReader.getRowNumber(), customerMap));
	                }
	                
	        }
	        finally {
	                if( mapReader != null ) {
	                        mapReader.close();
	                }
	        }
	}
}
