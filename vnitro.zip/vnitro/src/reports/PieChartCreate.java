package reports;

import java.awt.Color;
import java.awt.Font;
import java.io.File;
import java.io.IOException;

import org.jfree.chart.ChartRenderingInfo;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.entity.StandardEntityCollection;
import org.jfree.chart.plot.PiePlot;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.ui.RectangleInsets;
import org.jfree.util.UnitType;

public class PieChartCreate {

	public static void generatePieStatus() {
		double passValue = ReportUtil.DegreePass;
		double failValue = ReportUtil.DegreeFail;
		double skipValue = ReportUtil.DegreeSkip;
		double DegreeNoissue = ReportUtil.DegreeNoissueStatus;
		
		System.out.println("------pass-----" + passValue);
		System.out.println("------fail-----" + failValue);
		System.out.println("------skip-----" + skipValue);

		DefaultPieDataset pieDataset = new DefaultPieDataset();
		if(DegreeNoissue==360){
			pieDataset.setValue("NO_ISSUES", DegreeNoissue);
		}else if(DegreeNoissue==0){
			pieDataset.setValue("PASSED", passValue);
			pieDataset.setValue("FAILED", failValue);
			pieDataset.setValue("SKIPPED", skipValue);
		}
			

		System.out.println("DegreeNoissueStatus :"+DegreeNoissue);

		final PiePlot jobStatusPlot = new PiePlot(pieDataset);
		Font font = new Font("Arial Bold", 5, 11);
		jobStatusPlot.setLabelBackgroundPaint(Color.PINK);
		jobStatusPlot.setLabelPaint(Color.BLACK);

		jobStatusPlot.setLabelFont(font);
		RectangleInsets padding = new RectangleInsets(UnitType.RELATIVE, 3, 10,
				5, 10);
		jobStatusPlot.setLabelPadding(padding);

		jobStatusPlot.setSectionPaint("PASSED", Color.GREEN);
		jobStatusPlot.setSectionPaint("FAILED", Color.RED);
		jobStatusPlot.setSectionPaint("SKIPPED", Color.YELLOW);
		jobStatusPlot.setSectionPaint("NO_ISSUE", Color.WHITE);

		JFreeChart chart = new JFreeChart("Status PieChart",
				JFreeChart.DEFAULT_TITLE_FONT, jobStatusPlot, true);
		chart.setBackgroundPaint(java.awt.Color.LIGHT_GRAY);

		try {
			final ChartRenderingInfo info = new ChartRenderingInfo(
					new StandardEntityCollection());
			final File pieChartImage = new File(
					"../vnitro/VsoftReport/nitro/pieStatus.jpeg");
			ChartUtilities.saveChartAsPNG(pieChartImage, chart, 500, 500, info);

		} catch (IOException e) {
			System.out.println(e.toString());
		}
	}
	
	public static void generatePieSeverity() {
		double DegreeBlocker = ReportUtil.DegreeBlocker;
		double DegreeCritical = ReportUtil.DegreeCritical;
		double DegreeMajor = ReportUtil.DegreeMajor;
		double DegreeMinor = ReportUtil.DegreeMinor;
		double DegreeTrivial = ReportUtil.DegreeTrivial;
		double DegreeNoissue = ReportUtil.DegreeNoissueSeverity;
		System.out.println("------DegreeBlocker-----" + DegreeBlocker);
		System.out.println("------DegreeCritical-----" + DegreeCritical);
		System.out.println("------DegreeMajor-----" + DegreeMajor);
		System.out.println("------DegreeMinor-----" + DegreeMinor);
		System.out.println("------DegreeTrivial-----" + DegreeTrivial);
		System.out.println("DegreeNoissueSeverity :"+DegreeNoissue);
		DefaultPieDataset pieDataset = new DefaultPieDataset();
		
		if(DegreeNoissue==360){
			pieDataset.setValue("NO_ISSUES", DegreeNoissue);
		}else if(DegreeNoissue==0){
			pieDataset.setValue("BLOCKER", DegreeBlocker);
			pieDataset.setValue("CRITICAL", DegreeCritical);
			pieDataset.setValue("MAJOR", DegreeMajor);
			pieDataset.setValue("MINOR", DegreeMinor);
			pieDataset.setValue("TRIVIAL", DegreeTrivial);
		}

		final PiePlot jobStatusPlot = new PiePlot(pieDataset);
		Font font = new Font("Arial Bold", 5, 11);
		jobStatusPlot.setLabelBackgroundPaint(Color.PINK);
		jobStatusPlot.setLabelPaint(Color.BLACK);

		jobStatusPlot.setLabelFont(font);
		RectangleInsets padding = new RectangleInsets(UnitType.RELATIVE, 3, 10,
				5, 10);
		jobStatusPlot.setLabelPadding(padding);

		jobStatusPlot.setSectionPaint("TRIVIAL", Color.MAGENTA);
		jobStatusPlot.setSectionPaint("MINOR", Color.BLUE);
		jobStatusPlot.setSectionPaint("MAJOR", Color.YELLOW);
		jobStatusPlot.setSectionPaint("CRITICAL", Color.ORANGE);
		jobStatusPlot.setSectionPaint("BLOCKER", Color.RED);
		jobStatusPlot.setSectionPaint("NO_ISSUE", Color.WHITE);
		
		JFreeChart chart = new JFreeChart("Severity PieChart",
				JFreeChart.DEFAULT_TITLE_FONT, jobStatusPlot, true);
		chart.setBackgroundPaint(java.awt.Color.LIGHT_GRAY);

		try {
			final ChartRenderingInfo info = new ChartRenderingInfo(
					new StandardEntityCollection());
			final File pieChartImage = new File(
					"../vnitro/VsoftReport/nitro/pieSeverity.jpeg");
			ChartUtilities.saveChartAsPNG(pieChartImage, chart, 500, 500, info);

		} catch (IOException e) {
			System.out.println(e.toString());
		}
	}
}