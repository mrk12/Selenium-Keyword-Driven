package reports;

import java.io.*;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Time;
import java.text.ParseException;
import java.util.ArrayList;

import org.supercsv.cellprocessor.ParseInt;

import datatable.Xls_Reader;

import testscript.DriverScript;
import testscript.Keywords;
import util.CSVoperations;
import util.TestUtil;

public class ReportUtil {
	public static double DegreeBlocker;
	public static double DegreeCritical;
	public static double DegreeMajor;
	public static double DegreeMinor;
	public static int DegreeTrivial;
	public static int DegreeNoissueSeverity;
	public static int DegreeNoissueStatus;
	public static String compDuration_P= "0:0:0";
	public static String compDuration_C= "0:0:0";
	public static int compBreakage = 0;
	public static int compResolved = 0;
	public static String currentLine;
	public static String csvSuite_P;
	public static String csvTCID_P;
	public static String csvTCDesc_P;
	public static String csvTCSeverity_P;
	public static String csvTCDuration_P;
	public static String csvTCPerformance = "0:0:0";
	public static String csvTCDuration_P_prev = "0:0:0";
	public static String csvTCDuration_C_prev = "0:0:0";
	public static String csvIncDecPerf = "0:0:0";
	public static String csvTSID_P;
	public static String csvTSTestData_P;
	public static String csvTSDesc_P;
	public static String csvTSResult_P;
	public static String csvSuite_C;
	public static String csvTCID_C;
	public static String csvTCDesc_C;
	public static String csvTCSeverity_C;
	public static String csvTCDuration_C;
	public static String csvTSID_C;
	public static String csvTSTestData_C;
	public static String csvTSDesc_C;
	public static String csvTSResult_C;
	public static int scriptNumber = 1;
	public static String indexResultFilename;
	public static String currentDir;
	public static String currentSuiteName;
	public static int tcid;
	public static String app_url;
	public static String browser;
	public static String sign_off_status;
	public static String testCriteria;
	// public static String currentSuitePath;
	public static int TotalNumber;
	public static int passNumber;
	public static int failNumber;
	public static int skipNumber;
	public static double DegreePass;
	public static double DegreeFail;
	public static double DegreeSkip;
	public static double DefectRemovalEfficiency;
	public static boolean newTest = true;
	public static ArrayList<String> description = new ArrayList<String>();
	public static ArrayList<String> keyword = new ArrayList<String>();
	public static ArrayList<String> teststatus = new ArrayList<String>();
	public static ArrayList<String> screenShotPath = new ArrayList<String>();
	public static ArrayList<String> testStepData = new ArrayList<String>();
	public static int SeverityBlocker = 0;
	public static int SeverityCritical = 0;
	public static int SeverityMajor = 0;
	public static int SeverityMinor = 0;

	// public static void startTesting(String filename,String
	// testStartTime,String env,String rel)

	public static void startTesting(String filename, String testStartTime) {
		// indexResultFilename = filename;
		indexResultFilename = filename;
		System.out.println("indexResultFilename" + indexResultFilename);
		currentDir = indexResultFilename.substring(0,
				indexResultFilename.lastIndexOf("/"));
		System.out.println("currentDir :" + currentDir);
		FileWriter fstream = null;
		BufferedWriter out = null;
		try {
			// Create file

			fstream = new FileWriter(indexResultFilename);
			out = new BufferedWriter(fstream);

			String RUN_DATE = TestUtil.now("dd/MM/yyyy");

			// String ENVIRONMENT =
			// env;//SeleniumServerTest.ConfigurationMap.getProperty("environment");
			// String RELEASE =
			// rel;//SeleniumServerTest.ConfigurationMap.getProperty("release");

			out.newLine();

			out.write("<html>\n");
			out.write("<HEAD>\n");
			out.write(" <TITLE>PROJECTTITLE</TITLE>\n");
			out.write("</HEAD>\n");

			out.write("<body background=\"sky-blue-texture.jpg\">");
			out.write("<h4 align=center><FONT COLOR=660066 FACE=AriaL SIZE=6><b>PROJECTTITLE</b></h4>\n");
			out.write("<h2 align=center><FONT COLOR=660066 FACE=AriaL SIZE=3><b>version PROJECTVERSION</b></h2>\n");
			out.write("<table  border=1 cellspacing=1 cellpadding=1 >\n");
			out.write("<tr>\n");
			out.write("<h4 align=right><a href=\"CompareTestReports.html\" target=_blank><FONT COLOR=#AEAEAE FACE=Arial SIZE=2><b>Compare Test Reports</b></a></h4></td>");

			out.write("<h4 align=right><a href=\"SystemEnvironment.html\" target=_blank><FONT COLOR=#AEAEAE FACE=Arial SIZE=2><b>System Environment</b></a></h4></td>");
			out.write("<h4> <FONT COLOR=660000 FACE=Arial SIZE=4.5> Test Summary :</h4>\n");
			out.write("</tr>\n");

			out.write("<tr>\n");
			out.write("<td width=150 align=left bgcolor=#2d71dc><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2.75><b>Test Run Date</b></td>\n");
			out.write("<td width=150 align=left bgcolor=#2d71dc><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2.75><b>Duration</b></td>\n");
			out.write("<td width=150 align=left bgcolor=#2d71dc><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2.75><b>StartTime</b></td>\n");
			out.write("<td width=150 align= left  bgcolor=#2d71dc><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2.75><b>EndTime</b></td>\n");
			// out.write("<td width=150 align= left  bgcolor=#2d71dc rowspan=11>\n");
			// create applet for pie chart
			/*
			 * out.write("<APPLET CODE=\"reports.pieChart\" WIDTH=800 HEIGHT=400>"
			 * ); out.write("<PARAM NAME='pass' VALUE=DEGREEPASS>");
			 * out.write("<PARAM NAME='fail' VALUE=DEGREEFAIL>");
			 * out.write("<PARAM NAME='skip' VALUE=DEGREESKIP>");
			 * out.write("</APPLET>");
			 */
			out.write("<td align=left width=150 bgcolor=#2d71dc rowspan=11><img src=\"pieStatus.jpeg\"></td>");
			out.write("<td align=left width=150 bgcolor=#2d71dc rowspan=11><img src=\"pieSeverity.jpeg\"></td>");
			
			// out.write("</td>\n");
			out.write("</tr>\n");

			out.write("<tr>\n");
			out.write("<td width=150 align=left><FONT COLOR=#9d1826 FACE=Arial SIZE=2.75><b>"
					+ RUN_DATE + "</b></td>\n");
			out.write("<td width=150 align=left><FONT COLOR=#9d1826 FACE=Arial SIZE=2.75><b>DURATION</b></td>\n");
			out.write("<td width=150 align=left><FONT COLOR=#9d1826 FACE=Arial SIZE=2.75><b>"
					+ testStartTime + "</b></td>\n");
			out.write("<td width=150 align=left><FONT COLOR=#9d1826 FACE=Arial SIZE=2.75><b>END_TIME</b></td>\n");
			out.write("</tr>\n");

			out.write("<tr>\n");
			// out.write("<td width=150 align=left bgcolor=#2d71dc><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2.75><b>Total Testcases / With Iterations</b></td>\n");
			out.write("<td width=150 align=left bgcolor=#2d71dc><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2.75><b>Total Testcases</b></td>\n");
			out.write("<td width=150 align=left bgcolor=#2d71dc><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2.75><b>Passed</b></td>\n");
			out.write("<td width=150 align=left bgcolor=#2d71dc><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2.75><b>Failed</b></td>\n");
			out.write("<td width=150 align= left  bgcolor=#2d71dc><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2.75><b>Skipped</b></td>\n");
			out.write("</tr>\n");

			out.write("<tr>\n");
			// out.write("<td width=150 align=center><FONT COLOR=#9d1826 FACE=Arial SIZE=2.75><b>TOTALTC / TOTALPASSTCITERATION</b></td>\n");
			out.write("<td width=150 align=center><FONT COLOR=#9d1826 FACE=Arial SIZE=2.75><b>TOTALTC</b></td>\n");
			out.write("<td width=150 align=center><FONT COLOR=#9d1826 FACE= Arial  SIZE=2.75><b>TOTALPASSTC</b></td>\n");
			out.write("<td width=150 align=center><FONT COLOR=#9d1826 FACE= Arial  SIZE=2.75><b>TOTALFAILTC</b></td>\n");
			out.write("<td width=150 align=center><FONT COLOR=#9d1826 FACE=Arial SIZE=2.75><b>TOTALSKIPTC</b></td>\n");
			out.write("</tr>\n");

			out.write("<tr>\n");
			out.write("<td width=600 align=left bgcolor=#ff0000 colspan=4><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2.75><b>Failed TestCases Severity</b></td>\n");
			out.write("</tr>\n");

			out.write("<tr>\n");
			// out.write("<td width=150 align=left bgcolor=#2d71dc><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2.75><b>Total Testcases / With Iterations</b></td>\n");
			out.write("<td width=150 align=left bgcolor=#2d71dc><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2.75><b>Blockers</b></td>\n");
			out.write("<td width=150 align=left bgcolor=#2d71dc><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2.75><b>Critical</b></td>\n");
			out.write("<td width=150 align=left bgcolor=#2d71dc><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2.75><b>Major</b></td>\n");
			out.write("<td width=150 align= left  bgcolor=#2d71dc><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2.75><b>Minor</b></td>\n");
			out.write("</tr>\n");

			out.write("<tr>\n");
			// out.write("<td width=150 align=center><FONT COLOR=#9d1826 FACE=Arial SIZE=2.75><b>TOTALTC / TOTALPASSTCITERATION</b></td>\n");
			out.write("<td width=150 align=center><FONT COLOR=#9d1826 FACE=Arial SIZE=2.75><b>BUG_BLOCKER</b></td>\n");
			out.write("<td width=150 align=center><FONT COLOR=#9d1826 FACE= Arial  SIZE=2.75><b>BUG_CRITICAL</b></td>\n");
			out.write("<td width=150 align=center><FONT COLOR=#9d1826 FACE= Arial  SIZE=2.75><b>BUG_MAJOR</b></td>\n");
			out.write("<td width=150 align=center><FONT COLOR=#9d1826 FACE=Arial SIZE=2.75><b>BUG_MINOR</b></td>\n");
			out.write("</tr>\n");

			out.write("<tr>\n");
			out.write("<td width=150 align=left bgcolor=#2d71dc><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2.75><b>Browser</b></td>\n");
			out.write("<td width=150 align=left bgcolor=#2d71dc colspan=3><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2.75><b>Database Schema</b></td>\n");
			// out.write("<td width=150 align=left bgcolor=#2d71dc colspan=3><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2.75><b>Application URL</b></td>\n");
			out.write("</tr>\n");

			out.write("<tr>\n");
			out.write("<td width=150 align= left ><FONT COLOR=#9d1826 FACE= Arial  SIZE=2.75><b>BROWSER</b></td>\n");
			out.write("<td width=150 align= left colspan=3><FONT COLOR=#9d1826 FACE= Arial  SIZE=2.75><b>SCHEMA</b></td>\n");
			// out.write("<td width=150 align= left colspan=3><FONT COLOR=#9d1826 FACE= Arial  SIZE=2.75><b>APPLICATION_URL</b></td>\n");
			out.write("</tr>\n");

			out.write("<tr>\n");
			out.write("<td width=150 align=left bgcolor=#2d71dc colspan=4><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2.75><b>Application URL</b></td>\n");
			out.write("</tr>\n");

			out.write("<tr>\n");
			out.write("<td width=150 align= left colspan=4><FONT COLOR=#9d1826 FACE= Arial  SIZE=2.75><b>APPLICATION_URL</b></td>\n");
			out.write("</tr>\n");

			out.write("<tr>\n");
			out.write("<td width=150 align=left bgcolor=#2d71dc colspan=6 ><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2.75><b>Sign&nbsp;off&nbsp;Criteria&nbsp;&nbsp;(CRITERIA)</b></td>\n");
			out.write("</tr>\n");

			out.write("<tr>\n");
			out.write("SIGN_OFF_STATUS");
			out.write("</tr>\n");
			out.write("</table>");
			out.write("<h4>&nbsp;</h4>\n");
			out.write("<h4> <FONT COLOR=660000 FACE= Arial  SIZE=4.5>\n\n Test Details :</h4>\n");

			/*
			 * out.write("<table border=0 cellspacing=0 cellpadding=0 ><tr>");
			 * 
			 * out.write("<td><FONT COLOR= #000066  FACE= Arial  SIZE=2.75><b>"+""
			 * +"</b></td>"); out.write("GRAPH");
			 * 
			 * out.write("</tr></table>");
			 * 
			 * out.write(
			 * "<h4> <FONT COLOR=660000 FACE= Arial  SIZE=4.5> Detailed Report :</h4>"
			 * ); out.write("<table  border=1 cellspacing=1 cellpadding=1 >");
			 * out.write("<tr>"); out.write(
			 * "<td width=80  align= center  bgcolor=#2d71dc><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>Test Script#</b></td>"
			 * );
			 * 
			 * out.write(
			 * "<td width=300 align= center  bgcolor=#2d71dc><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>Test Case Name</b></td>"
			 * ); out.write(
			 * "<td width=75 align= center  bgcolor=#2d71dc><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>Status</b></td>"
			 * ); out.write(
			 * "<td width=200 align= center  bgcolor=#2d71dc><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>Run End Time</b></td>"
			 * ); out.write("</tr>");
			 */
			// Close the output stream
			out.close();
		} catch (Exception e) {// Catch exception if any
			System.err.println("Error: " + e.getMessage());
		} finally {

			fstream = null;
			out = null;
		}
	}

	public static void startSuite(String suiteName, int totalSuite) {

		FileWriter fstream = null;
		BufferedWriter out = null;
		currentSuiteName = suiteName.replaceAll(" ", "_");
		tcid = 1;
		try {
			// build the suite folder
			// currentSuitePath = currentDir;
			// //+"//"+suiteName.replaceAll(" ","_");
			// currentSuiteDir = suiteName.replaceAll(" ","_");
			// File f = new File(currentSuitePath);
			// f.mkdirs();

			fstream = new FileWriter(indexResultFilename, true);
			out = new BufferedWriter(fstream);
			if (totalSuite > 1) {
				out.write("<h3 align=center> <FONT COLOR=660000 FACE= Arial  SIZE=4.5> "
						+ suiteName + "</h3>\n");
			}
			out.write("<table  border=1 cellspacing=1 cellpadding=1 width=100%>\n");
			out.write("<tr>\n");
			out.write("<td width=5%  align= center  bgcolor=#2d71dc><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>Sl.No#</b></td>\n");
			out.write("<td width=10% align= center  bgcolor=#2d71dc><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>TestCase</b></td>\n");
			out.write("<td width=30% align= center  bgcolor=#2d71dc><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>TestCase Description</b></td>\n");
			out.write("<td width=10% align= center  bgcolor=#2d71dc><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>Status</b></td>\n");
			out.write("<td width=15% align= center  bgcolor=#2d71dc><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>Run Start Time</b></td>\n");
			out.write("<td width=15% align= center  bgcolor=#2d71dc><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>Run End Time</b></td>\n");
			out.write("<td width=15% align= center  bgcolor=#2d71dc><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>Run Duration</b></td>\n");
			out.write("<td width=15% align= center  bgcolor=#2d71dc><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>Severity</b></td>\n");

			out.write("</tr>\n");
			out.close();
		} catch (Exception e) {
			System.err.println("Error: " + e.getMessage());
		} finally {

			fstream = null;
			out = null;
		}
	}

	public static void endSuite() {
		FileWriter fstream = null;
		BufferedWriter out = null;

		try {
			fstream = new FileWriter(indexResultFilename, true);
			out = new BufferedWriter(fstream);
			out.write("</table>\n");
			out.close();
		} catch (Exception e) {
			System.err.println("Error: " + e.getMessage());
		} finally {

			fstream = null;
			out = null;
		}
	}

	public static void addTestCase(String testCaseName,
			String testCaseStartTime, String testCaseEndTime, String status,
			String finalStatus, String tdID, String testCaseDesc,
			String severity) {
		// System.out.println("testCaseStartTime"+testCaseStartTime);
		String tcDuration = TestUtil.timeDifference(testCaseStartTime,
				testCaseEndTime);
		newTest = true;
		FileWriter fstream = null;
		BufferedWriter out = null;
		try {
			newTest = true;
			// build the keywords page
			if (status.equalsIgnoreCase("Skipped")
					|| status.equalsIgnoreCase("Skip")) {
			} else {
				// FnScreenShot fss=new FnScreenShot();
				String scrFilePath = currentDir + "/" + currentSuiteName
						+ "_TC" + tcid + "_"
						+ testCaseName.replaceAll(" ", "_") + ".html";
				System.out.println("scrFilePath : " + scrFilePath);
				File f = new File(scrFilePath);
				f.createNewFile();
				fstream = new FileWriter(scrFilePath);
				out = new BufferedWriter(fstream);
				out.write("<html>");
				out.write("<head>");
				out.write("<title>");
				out.write(testCaseName + " Detailed Reports");
				out.write("</title>");
				out.write("</head>");
				out.write("<body background=\"sky-blue-texture.jpg\">");
				out.write("<h4 align=center> <FONT COLOR=660000 FACE=Arial SIZE=4.5> Detailed Report : "
						+ testCaseName + "  ->  " + testCaseDesc + "</h4>");
				out.write("<table  border=1 cellspacing=1    cellpadding=1 width=100%>");

				out.write("<tr> ");
				out.write("<td align=center width=5%  bgcolor=#2d71dc><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2><b>Steps#</b></td>");
				out.write("<td align=center width=40% bgcolor=#2d71dc><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2><b>Description</b></td>");
				out.write("<td align=center width=10% bgcolor=#2d71dc><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2><b>Keyword</b></td>");
				out.write("<td align=center width=20% bgcolor=#2d71dc><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2><b>Test Data</b></td>");
				out.write("<td align=center width=10% bgcolor=#2d71dc><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2><b>Result</b></td>");
				out.write("<td align=center width=15% bgcolor=#2d71dc><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2><b>Screen Shot</b></td>");
				out.write("</tr>");
				if (description != null) {
					for (int i = 0; i < description.size(); i++) {
						// System.out.println("screenShotPath.get(i)------>"+screenShotPath.get(i));
						// fss.ScnRetrieve(screenShotPath.get(i));
						out.write("<tr> ");

						out.write("<td  width=5% ><FONT COLOR=#9d1826 FACE=Arial SIZE=1><b>TS"
								+ (i + 1) + "</b></td>");
						out.write("<td  width=40%><FONT COLOR=#9d1826 FACE=Arial SIZE=1><b>"
								+ description.get(i) + "</b></td>");
						out.write("<td  width=10%><FONT COLOR=#9d1826 FACE=Arial SIZE=1><b>"
								+ keyword.get(i) + "</b></td>");
						out.write("<td align=center width=20%><FONT COLOR=#9d1826 FACE=Arial SIZE=1><b>"
								+ testStepData.get(i) + "</b></td>");

						if (teststatus.get(i).startsWith("Pass"))
							out.write("<td width=10% align= center  bgcolor=#009600><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2><b>"
									+ teststatus.get(i) + "</b></td>\n");
						else if (teststatus.get(i).startsWith("Fail"))
							out.write("<td width=10% align= center  bgcolor=#C80000><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>"
									+ teststatus.get(i) + "</b></td>\n");

						// out.write("<td  width=20%><FONT COLOR=#9d1826 FACE=Arial SIZE=1><b>"+teststatus.get(i)+"</b></td>");

						// retrieve screenshot from physical location
						boolean fileExists = TestUtil
								.checkFileExists(DriverScript.CONFIG
										.getProperty("screenshotPath")
										+ screenShotPath.get(i));
						if (fileExists)
							out.write("<td align=center width=15%><FONT COLOR=#9d1826 FACE=Arial SIZE=1><b><a href="
									+ "ScreenShots/"
									+ screenShotPath.get(i)
									+ " target=_blank>Screen Shot</a></b></td>");
						else
							out.write("<td align=center width=15%><FONT COLOR=#9d1826 FACE=Arial SIZE=1><b>&nbsp;</b></td>");

						// retrieve screenshot from db
						// out.write("<td align=center width=15%><img src=<%o.write(brr); %> width=\"117\" height=\"160\"></td>");
						out.write("</tr>");
					}
				}
				out.close();
			}

			fstream = new FileWriter(indexResultFilename, true);
			out = new BufferedWriter(fstream);

			fstream = new FileWriter(indexResultFilename, true);
			out = new BufferedWriter(fstream);
			// out.newLine();

			out.write("<tr>\n");
			// System.out.println(currentSuitePath);
			// out.write("<td width=10% align= center ><FONT COLOR=#9d1826 FACE= Arial  SIZE=2><b>"+scriptNumber+"</b></td>\n");
			if (finalStatus.equalsIgnoreCase("Skipped")
					|| status.equalsIgnoreCase("Skip")) {
				out.write("<td width=5% align= center ><FONT COLOR=#9d1826 FACE= Arial  SIZE=2><b>"
						+ scriptNumber + "</b></td>\n");
				out.write("<td width=5% align=left ><FONT COLOR=#9d1826 FACE= Arial  SIZE=2><b>"
						+ testCaseName + "</b></td>\n");
				out.write("<td width=35% align= left ><FONT COLOR=#9d1826 FACE= Arial  SIZE=2><b>"
						+ testCaseDesc + "</b></td>\n");
				// out.write("<td width=15% align= center ><FONT COLOR=#9d1826 FACE= Arial  SIZE=2><b>"+tdID+"</b></td>\n");
				// out.write("<td width=15% align= center ><FONT COLOR=#9d1826 FACE= Arial  SIZE=2>&nbsp;</td>\n");
			} else {
				out.write("<td width=5% align= center ><FONT COLOR=#9d1826 FACE= Arial  SIZE=2><b><a href=./"
						+ currentSuiteName
						+ "_TC"
						+ tcid
						+ "_"
						+ testCaseName.replaceAll(" ", "_")
						+ ".html>"
						+ scriptNumber + "</a></b></td>\n");
				out.write("<td width=5% align= left ><FONT COLOR=#9d1826 FACE= Arial  SIZE=2><b>"
						+ testCaseName + "</b></td>\n");
				out.write("<td width=35% align= left ><FONT COLOR=#9d1826 FACE= Arial  SIZE=2><b>"
						+ testCaseDesc + "</b></td>\n");
				// out.write("<td width=15% align= center ><FONT COLOR=#9d1826 FACE= Arial  SIZE=2><b>"+tdID+"</b></td>\n");
			}
			// if(status.equalsIgnoreCase("Skipped") ||
			// status.equalsIgnoreCase("Skip"))
			// out.write("<td width=40% align= center ><FONT COLOR=#9d1826 FACE= Arial  SIZE=2><b>"+testCaseName+"</b></td>\n");
			// else
			// out.write("<td width=40% align= center ><FONT COLOR=#9d1826 FACE= Arial  SIZE=2><b><a href=file://"+currentDir+"/"+currentSuiteName+"_TC"+tcid+"_"+testCaseName.replaceAll(" ",
			// "_")+".html>"+testCaseName+"</a>-"+tdID+"</b></td>\n");

			tcid++;

			if (finalStatus.startsWith("Pass")) {
				out.write("<td width=10% align= center  bgcolor=#009600><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2><b>"
						+ finalStatus + "</b></td>\n");
				out.write("<td width=10% align= center ><FONT COLOR=#9d1826 FACE= Arial  SIZE=2><b>"
						+ testCaseStartTime + "</b></td>\n");
				out.write("<td width=10% align= center ><FONT COLOR=#9d1826 FACE= Arial  SIZE=2><b>"
						+ testCaseEndTime + "</b></td>\n");
				out.write("<td width=10% align= center ><FONT COLOR=#9d1826 FACE= Arial  SIZE=2><b>"
						+ tcDuration + "</b></td>\n");
				out.write("<td width=15% align= center ><FONT COLOR=#9d1826 FACE= Arial  SIZE=2><b>&nbsp;</b></td>\n");
				passNumber++;
				TotalNumber++;
				System.out.println("severity pass: " + severity);
			} else if (finalStatus.startsWith("Fail")) {
				out.write("<td width=10% align= center  bgcolor=#C80000><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>"
						+ finalStatus + "</b></td>\n");
				out.write("<td width=10% align= center ><FONT COLOR=#9d1826 FACE= Arial  SIZE=2><b>"
						+ testCaseStartTime + "</b></td>\n");
				out.write("<td width=10% align= center ><FONT COLOR=#9d1826 FACE= Arial  SIZE=2><b>"
						+ testCaseEndTime + "</b></td>\n");
				out.write("<td width=10% align= center ><FONT COLOR=#9d1826 FACE= Arial  SIZE=2><b>"
						+ tcDuration + "</b></td>\n");
				out.write("<td width=15% align= center ><FONT COLOR=#9d1826 FACE= Arial  SIZE=2><b>"
						+ severity + "</b></td>\n");
				failNumber++;
				TotalNumber++;
				System.out.println("severity fail: " + severity);
				if (severity.startsWith("Blocker")) {
					SeverityBlocker++;
				} else if (severity.startsWith("Critical")) {
					SeverityCritical++;
				} else if (severity.startsWith("Major")) {
					SeverityMajor++;
				} else if (severity.startsWith("Minor")) {
					SeverityMinor++;
				}
			} else if (finalStatus.equalsIgnoreCase("Skipped")
					|| status.equalsIgnoreCase("Skip") || finalStatus.isEmpty()) {
				out.write("<td width=10% align= center  bgcolor=#FF9696><FONT COLOR=153E7E FACE=Arial SIZE=2><b>"
						+ finalStatus + "</b></td>\n");
				out.write("<td width=15% align= center ><FONT COLOR=#9d1826 FACE= Arial  SIZE=2><b>&nbsp;</b></td>\n");
				out.write("<td width=15% align= center ><FONT COLOR=#9d1826 FACE= Arial  SIZE=2><b>&nbsp;</b></td>\n");
				out.write("<td width=15% align= center ><FONT COLOR=#9d1826 FACE= Arial  SIZE=2><b>&nbsp;</b></td>\n");
				out.write("<td width=15% align= center ><FONT COLOR=#9d1826 FACE= Arial  SIZE=2><b>&nbsp;</b></td>\n");
				skipNumber++;
				TotalNumber++;
				System.out.println("severity skip: " + severity);
			}

			// out.write("<td width=20% align= center ><FONT COLOR=#9d1826 FACE= Arial  SIZE=2><b>"+testCaseStartTime+"</b></td>\n");
			// out.write("<td width=20% align= center ><FONT COLOR=#9d1826 FACE= Arial  SIZE=2><b>"+testCaseEndTime+"</b></td>\n");
			// out.write("<td width=20% align= center ><FONT COLOR=#9d1826 FACE= Arial  SIZE=2><b>"+tcDuration+"</b></td>\n");
			out.write("</tr>\n");

			scriptNumber++;
		} catch (IOException e) {
			e.printStackTrace();
			return;
		} finally {
			try {
				out.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		description = new ArrayList<String>();
		keyword = new ArrayList<String>();
		teststatus = new ArrayList<String>();
		screenShotPath = new ArrayList<String>();
		testStepData = new ArrayList<String>();
		newTest = false;
	}

	public static void addKeyword(String desc, String key, String stat,
			String path, String tsData) {
		description.add(desc);
		keyword.add(key);
		teststatus.add(stat);
		screenShotPath.add(path);
		testStepData.add(tsData);
	}

	public static void addSystemEnvironment() {
		newTest = true;
		FileWriter fstream = null;
		BufferedWriter out = null;
		try {
			String FilePath = currentDir + "/SystemEnvironment.html";
			System.out.println("SystemEnvironment_currentDir :" + currentDir);
			File f = new File(FilePath);
			f.createNewFile();
			fstream = new FileWriter(FilePath);
			out = new BufferedWriter(fstream);
			out.write("<html>");
			out.write("<head>");
			out.write("<title>");
			out.write("System Environment");
			out.write("</title>");
			out.write("</head>");
			out.write("<body background=\"sky-blue-texture.jpg\">");
			out.write("<h4 align=center> <FONT COLOR=660000 FACE=Arial SIZE=6> System Environment</h4>");
			out.write("<table  border=1 cellspacing=1    cellpadding=1 width=500px>");
			out.write("<h4>&nbsp;</h4>\n");
			out.write("<h4> <FONT COLOR=660000 FACE= Arial  SIZE=3>\n\n Server Environment:</h4>\n");
			out.write("<tr> ");
			out.write("<td  width=30%  align=right bgcolor=#2d71dc><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2><b>Processor : </b></td>");
			out.write("<td  width=80%  align=left><FONT COLOR=#9d1826 FACE=Arial SIZE=2 align=left><b>"
					+ DriverScript.CONFIG.getProperty("Server_Processor")
					+ "</b></td>");
			out.write("</tr>");
			out.write("<tr> ");
			out.write("<td  width=30% align=right bgcolor=#2d71dc><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2><b>RAM : </b></td>");
			out.write("<td  width=70%  align=left><FONT COLOR=#9d1826 FACE=Arial SIZE=2><b>"
					+ DriverScript.CONFIG.getProperty("Server_RAM")
					+ "</b></td>");
			out.write("</tr>");
			out.write("<tr> ");
			out.write("<td  width=30% align=right bgcolor=#2d71dc><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2><b>Application Server : </b></td>");
			out.write("<td  width=70%  align=left><FONT COLOR=#9d1826 FACE=Arial SIZE=2><b>"
					+ DriverScript.CONFIG
							.getProperty("Server_ApplicationServer")
					+ "</b></td>");
			out.write("</tr>");
			out.write("<tr> ");
			out.write("<td  width=30% align=right bgcolor=#2d71dc><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2><b>Database : </b></td>");
			out.write("<td  width=70%  align=left><FONT COLOR=#9d1826 FACE=Arial SIZE=2><b>"
					+ DriverScript.CONFIG.getProperty("Server_Database")
					+ "</b></td>");
			out.write("</tr>");
			out.write("<tr> ");
			out.write("<td  width=30% align=right bgcolor=#2d71dc><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2><b>Schema : </b></td>");
			out.write("<td  width=70%  align=left><FONT COLOR=#9d1826 FACE=Arial SIZE=2><b>"
					+ DriverScript.CONFIG.getProperty("Server_Schema")
					+ "</b></td>");
			out.write("</tr>");
			out.write("<tr> ");
			out.write("<td  width=30% align=right bgcolor=#2d71dc><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2><b>Java : </b></td>");
			out.write("<td  width=70%  align=left><FONT COLOR=#9d1826 FACE=Arial SIZE=2><b>"
					+ DriverScript.CONFIG.getProperty("Server_Java")
					+ "</b></td>");
			out.write("</tr>");
			out.write("</table>");
			out.write("<table  border=1 cellspacing=1    cellpadding=1 width=500px>");
			out.write("<h4>&nbsp;</h4>\n");
			out.write("<h4> <FONT COLOR=660000 FACE= Arial  SIZE=3>\n\n Test run Environment:</h4>\n");
			out.write("<tr> ");
			out.write("<td  width=30%  align=right bgcolor=#2d71dc><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2><b>Processor : </b></td>");
			out.write("<td  width=70%  align=left><FONT COLOR=#9d1826 FACE=Arial SIZE=2><b>"
					+ DriverScript.CONFIG.getProperty("Client_Processor")
					+ "</b></td>");
			out.write("</tr>");
			out.write("<tr> ");
			out.write("<td  width=30% align=right bgcolor=#2d71dc ><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2><b>RAM : </b></td>");
			out.write("<td  width=70%  align=left><FONT COLOR=#9d1826 FACE=Arial SIZE=2><b>"
					+ DriverScript.CONFIG.getProperty("Client_RAM")
					+ "</b></td>");
			out.write("</tr>");
			out.write("<tr> ");
			out.write("<td  width=30% align=right bgcolor=#2d71dc><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2><b>Display Resolution : </b></td>");
			out.write("<td  width=70%  align=left><FONT COLOR=#9d1826 FACE=Arial SIZE=2><b>"
					+ DriverScript.CONFIG.getProperty("Client_Display")
					+ "</b></td>");
			out.write("</tr>");
			out.write("<tr>");
			out.write("<td  width=30% align=right bgcolor=#2d71dc ><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2><b>Java : </b></td>");
			out.write("<td  width=70%  align=left><FONT COLOR=#9d1826 FACE=Arial SIZE=2><b>"
					+ DriverScript.CONFIG.getProperty("Client_Java")
					+ "</b></td>");
			out.write("</tr>");
			out.write("<tr> ");
			out.write("<td  width=30% align=right bgcolor=#2d71dc><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2><b>Web Browser : </b></td>");
			out.write("<td  width=70%  align=left ><FONT COLOR=#9d1826 FACE=Arial SIZE=2><b>"
					+ DriverScript.CONFIG.getProperty("Client_WebBrowser")
					+ "</b></td>");
			out.write("</tr>");
			out.write("</table>");
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
			return;
		} finally {
			try {
				out.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		description = new ArrayList<String>();
		keyword = new ArrayList<String>();
		teststatus = new ArrayList<String>();
		screenShotPath = new ArrayList<String>();
		testStepData = new ArrayList<String>();
		newTest = false;

	}

	public static void CompareTestReports() throws ParseException {
		DriverScript.compareCSV_P = new Xls_Reader(DriverScript.class
				.getResource("/CSV/csvAutomation-P.xls").getFile());
		String fileController1 = DriverScript.class.getResource(
				"/CSV/csvAutomation-P.xls").getFile();
		DriverScript.compareCSV_C = new Xls_Reader(DriverScript.class
				.getResource("/CSV/csvAutomation-C.xls").getFile());
		String fileController2 = DriverScript.class.getResource(
				"/CSV/csvAutomation-C.xls").getFile();
		
		compBreakage=0;
		compResolved=0;
		//csvTCDuration_C_prev="0:0:0";
		//csvTCDuration_P_prev="0:0:0";
		
		System.out.println("Inside CompareTestReports");
		FileWriter fstream = null;
		BufferedWriter out = null;

		String FilePath = currentDir + "/CompareTestReports.html";
		System.out.println("CompareTestReports_currentDir :" + currentDir);
		File f = new File(FilePath);
		try {
			f.createNewFile();

			fstream = new FileWriter(FilePath);
			out = new BufferedWriter(fstream);
			out.write("<html>");
			out.write("<head>");
			out.write("<title>");
			out.write(" Compare Test Reports");
			out.write("</title>");
			out.write("</head>");
			out.write("<body background=\"sky-blue-texture.jpg\">");
			out.write("<h4 align=center> <FONT COLOR=660000 FACE=Arial SIZE=6>Comparison Test Reports</h4>");
			out.write("<table  border=1 cellspacing=1    cellpadding=1 width=200px>");
			out.write("<h4>&nbsp;</h4>\n");
			out.write("<h4> <FONT COLOR=660000 FACE= Arial  SIZE=3>\n\n Comparison Summary:</h4>\n");
			out.write("<tr> ");
			out.write("<th align=center width=20%   bgcolor=#2d71dc><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2><b>Performance</b></th>");
			out.write("<th align=center width=10%   bgcolor=#2d71dc><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2><b>Breakage</b></th>");
			out.write("<th align=center width=10%   bgcolor=#2d71dc><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2><b>Resolved</b></th>");
			out.write("</tr>");
			out.write("<tr> ");
			//out.write("<td align=center width=20%  align=right><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2><b>PERFORMANCE</b></td>");
			out.write("PERFORMANCE");
			out.write("<td align=center width=10%  ><FONT COLOR=#9d1826 FACE=Arial SIZE=2><b>BREAKAGE</b></td>");
			out.write("<td align=center width=10% ><FONT COLOR=#9d1826 FACE=Arial SIZE=2><b>RESOLVED</b></td>");
			out.write("</tr>");
			out.write("</table>");

			out.write("<table  border=1 cellspacing=1    cellpadding=1 width=100%>");
			out.write("<h4>&nbsp;</h4>\n");
			out.write("<h4> <FONT COLOR=660000 FACE= Arial  SIZE=3>\n\n Test Results:</h4>\n");
			out.write("<tr> ");
			out.write("<th align=center width=10%   bgcolor=#2d71dc><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2><b>TCID</b></th>");
			out.write("<th align=center width=20%   bgcolor=#2d71dc><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2><b>Description</b></th>");
			out.write("<th align=center width=10%   bgcolor=#2d71dc><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2><b>Duration(Prev.)</b></th>");
			out.write("<th align=center width=10%   bgcolor=#2d71dc><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2><b>Duration(Curr.)</b></th>");
			out.write("<th align=center width=10%   bgcolor=#2d71dc><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2><b>Duration(Prev-Curr)</b></th>");
			out.write("<th align=center width=5%   bgcolor=#2d71dc><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2><b>Severity</b></th>");
			out.write("<th align=center width=5%   bgcolor=#2d71dc><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2><b>Status(Prev.)</b></th>");
			out.write("<th align=center width=5%   bgcolor=#2d71dc><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2><b>Status(Curr.)</b></th>");
			out.write("</tr>");

			currentLine = "ComparisonReport";
			/*
			 * if(DriverScript.compareCSV_P.isSheetExist(currentLine)){
			 * System.out.println("ComparisonReport P Exists!!!"); } else{
			 * System.out.println("ComparisonReport P does not Exist!!!"); }
			 * 
			 * try{ if(DriverScript.compareCSV_C.isSheetExist(currentLine)){
			 * System.out.println("ComparisonReport C Exists!!!"); } else{
			 * System.out.println("ComparisonReport C does not Exist!!!"); }
			 * }catch(Exception e){e.printStackTrace();}
			 */

			int maxRows = 0;
			if (DriverScript.compareCSV_P.getRowCount(currentLine) > DriverScript.compareCSV_C
					.getRowCount(currentLine)) {
				maxRows = DriverScript.compareCSV_P.getRowCount(currentLine);
			} else {
				maxRows = DriverScript.compareCSV_C.getRowCount(currentLine);
			}
			System.out.println("max Rows" + maxRows);

			for (int tsid = 2; tsid <= maxRows; tsid++) {
				csvTCID_P = DriverScript.compareCSV_P.getCellData(currentLine,
						"TCID", tsid);
				csvTCDesc_P = DriverScript.compareCSV_P.getCellData(
						currentLine, "DESCRIPTION", tsid);
				csvTCDuration_P = DriverScript.compareCSV_P.getCellData(
						currentLine, "DURATION", tsid);
				csvTCSeverity_P = DriverScript.compareCSV_P.getCellData(
						currentLine, "SEVERITY", tsid);
				csvTSResult_P = DriverScript.compareCSV_P.getCellData(
						currentLine, "STATUS", tsid);

				csvTCID_C = DriverScript.compareCSV_C.getCellData(currentLine,
						"TCID", tsid);
				csvTCDesc_C = DriverScript.compareCSV_C.getCellData(
						currentLine, "DESCRIPTION", tsid);
				csvTCDuration_C = DriverScript.compareCSV_C.getCellData(
						currentLine, "DURATION", tsid);
				csvTCSeverity_C = DriverScript.compareCSV_C.getCellData(
						currentLine, "SEVERITY", tsid);
				csvTSResult_C = DriverScript.compareCSV_C.getCellData(
						currentLine, "STATUS", tsid);

				System.out.println("Previous : tsid~~~~~~~" + tsid + "~~~~~~csvTCID:"
						+ csvTCID_P + "; csvTCDesc prev:" + csvTCDesc_P);
				System.out.println("Current : tsid~~~~~~~" + tsid + "~~~~~~csvTCID:"
						+ csvTCID_C + "; csvTCDesc curr:" + csvTCDesc_C);

				DriverScript.APPICATION_LOGS.error("~~~~~~~" + tsid
						+ "~~~~~~keyword:" + csvTCID_P + "; stepDescription:"
						+ csvTCDesc_P);

				out.write("<tr> ");
				out.write("<td  width=10% align=left><FONT COLOR=#9d1826 FACE=Arial SIZE=2><b>"
						+ csvTCID_P + "</b></td>");
				out.write("<td  width=20%  align=left><FONT COLOR=#9d1826 FACE=Arial SIZE=2><b>"
						+ csvTCDesc_P + "</b></td>");
				out.write("<td  width=7%  align=center><FONT COLOR=#9d1826 FACE=Arial SIZE=2><b>"
						+ csvTCDuration_P + "</b></td>");
				out.write("<td  width=7%  align=center ><FONT COLOR=#9d1826 FACE=Arial SIZE=2><b>"
						+ csvTCDuration_C + "</b></td>");
				
				String csvTCDurationDiff=TestUtil.timeDifference(csvTCDuration_C,csvTCDuration_P);
				csvIncDecPerf=TestUtil.timeIncDec(csvTCDuration_C,csvTCDuration_P);
				System.out.println("return : "+csvIncDecPerf);
				if(csvIncDecPerf.equals("Decrease"))
					out.write("<td  width=7%  align=center ><FONT COLOR=#9d1826 FACE=Arial SIZE=2><b>-"+csvTCDurationDiff+"</b></td>");
				else
					out.write("<td  width=7%  align=center ><FONT COLOR=#9d1826 FACE=Arial SIZE=2><b>"+csvTCDurationDiff+"</b></td>");
					
				out.write("<td  width=5%  align=left ><FONT COLOR=#9d1826 FACE=Arial SIZE=2><b>"
						+ csvTCSeverity_P + "</b></td>");
				
				
				compDuration_P = TestUtil.timeAddition(compDuration_P , csvTCDuration_P);
				System.out.println("compDuration_P@"+compDuration_P);
				
				compDuration_C = TestUtil.timeAddition(compDuration_C ,csvTCDuration_C);
				System.out.println("compDuration_C@"+compDuration_C);
				
				csvTCDuration_P_prev = TestUtil.timeAddition(csvTCDuration_P_prev, csvTCDuration_P);
				System.out.println("csvTCDuration_P_prev@"+csvTCDuration_P_prev);
				
				csvTCDuration_C_prev = TestUtil.timeAddition(csvTCDuration_C_prev, csvTCDuration_C);
				System.out.println("csvTCDuration_C_prev@"+csvTCDuration_C_prev);
				
				if (csvTSResult_P.startsWith("Fail")) {
					csvTSResult_P = "Fail";
					out.write("<td align=center width=5%  bgcolor=#ff0000><FONT COLOR=BLACK FACE=Arial SIZE=2><b>"
							+ csvTSResult_P + "</b></td>");
				} else {
					out.write("<td align=center width=5%  ><FONT COLOR=#9d1826 FACE=Arial SIZE=2><b>"
							+ csvTSResult_P + "</b></td>");
				}
				if (csvTSResult_C.startsWith("Fail")) {
					csvTSResult_C = "Fail";
					out.write("<td align=center width=5%  bgcolor=#ff0000><FONT COLOR=BLACK FACE=Arial SIZE=2><b>"
							+ csvTSResult_C + "</b></td>");
				} else {
					out.write("<td align=center width=5%  ><FONT COLOR=#9d1826 FACE=Arial SIZE=2><b>"
							+ csvTSResult_C + "</b></td>");
				}
				System.out.println("csvTSResult_P : "+csvTSResult_P+"-------csvTSResult_C : "+csvTSResult_C);
				csvTSResult_P=csvTSResult_P.trim();
				csvTSResult_C=csvTSResult_C.trim();
				if (csvTSResult_P.equals("Fail") && csvTSResult_C.equals("Pass")) {
					System.out.println("inside if Breakage");
					compResolved++;
				}
				if (csvTSResult_P.equals("Pass") && csvTSResult_C.equals("Fail")) {
					System.out.println("inside if Resolved");
					compBreakage++;
				}
				if (csvTSResult_P.equals("Pass") && csvTSResult_C.equals("Pass")) {
					System.out.println("inside if Pass-Pass");
				}
				if (csvTSResult_P.equals("Fail") && csvTSResult_C.equals("Fail")) {
					System.out.println("inside if Fail-Fail");
				}
				out.write("</tr>");
			}
			out.write("</table>");
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
			return;
		} finally {
			try {
				out.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	@SuppressWarnings("resource")
	public static void updateComparisonReportSummary() throws ParseException {
		System.out.println("compBreakage=====" + compBreakage);
		System.out.println("compResolved=====" + compResolved);
		String comparisonReportFilename = currentDir + "/CompareTestReports.html";
		csvIncDecPerf=TestUtil.timeIncDec(csvTCDuration_C_prev,csvTCDuration_P_prev);
		csvTCPerformance=TestUtil.timeDifference(csvTCDuration_C_prev,csvTCDuration_P_prev);
		StringBuffer buf = new StringBuffer();
		try {
			// Open the file that is the first
			// command line parameter
			FileInputStream fstream = new FileInputStream(
					comparisonReportFilename);
			// Get the object of DataInputStream
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			String strLine;
			
			String Performance_Dec="<td align=center width=20%  align=right bgcolor=#ff0000><FONT COLOR=BLACK FACE=Arial SIZE=2><b>"+csvIncDecPerf+" by "+csvTCPerformance+"</b></td>";
			String Performance_Inc="<td align=center width=20%  align=right bgcolor=#00ff00><FONT COLOR=BLACK FACE=Arial SIZE=2><b>"+csvIncDecPerf+" by "+csvTCPerformance+"</b></td>";
			String Performance_nil="<td align=center width=20%  align=right ><FONT COLOR=BLACK FACE=Arial SIZE=2><b>"+csvTCPerformance+"</b></td>";
			// Read File Line By Line
			while ((strLine = br.readLine()) != null) {
				if (strLine.indexOf("PERFORMANCE") != -1) {
					if(csvIncDecPerf.equals("Increase")){
						strLine = strLine.replace("PERFORMANCE",Performance_Inc);
					}
					else if(csvIncDecPerf.equals("Decrease")){
						strLine = strLine.replace("PERFORMANCE",Performance_Dec);
					}
					else{
						strLine = strLine.replace("PERFORMANCE",Performance_nil);
					}
				}
				if (strLine.indexOf("BREAKAGE") != -1) {
					strLine = strLine.replace("BREAKAGE",
							String.valueOf(compBreakage));
				}
				if (strLine.indexOf("RESOLVED") != -1) {
					strLine = strLine.replace("RESOLVED",
							String.valueOf(compResolved));
				}
				buf.append(strLine);
			}
			// Close the input stream
			in.close();
			System.out.println("buffer:" + buf);
			FileOutputStream fos = new FileOutputStream(
					comparisonReportFilename);
			DataOutputStream output = new DataOutputStream(fos);
			output.writeBytes(buf.toString());
			fos.close();

		} catch (Exception e) {// Catch exception if any
			System.err.println("Error: " + e.getMessage());
		}
	}

	public static void updateHTMLSummary(String endTime, int TOTALTC,
			String duration, String projectTitle, String projectVersion,
			String tdID, String execution_no, String Schema) {
		StringBuffer buf = new StringBuffer();
		try {
			FileWriter fstream1 = null;
			BufferedWriter out = null;

			try {
				fstream1 = new FileWriter(indexResultFilename, true);
				out = new BufferedWriter(fstream1);
				out.write("<table width=100%> ");
				out.write("<tr><td>&nbsp;</td></tr> ");
				out.write("<tr>");
				out.write("<td align=right width=100%><FONT COLOR=#AEAEAE FACE=Arial SIZE=2><b>No. of execution: "
						+ execution_no + "</b></td>");
				out.write("<tr>");
				out.write("<tr>");
				out.write("<td align=center width=100%><a href=\"http://www.vsoftcorp.com\" target=_blank><FONT COLOR=#AEAEAE FACE=Arial SIZE=2><b>generated @ vsoftcorp</b></a></td>");
				out.write("<tr></table>");
				out.close();
			} catch (Exception e) {
				System.err.println("Error: " + e.getMessage());
			} finally {
				fstream1 = null;
				out = null;
			}

			// Open the file that is the first
			// command line parameter
			FileInputStream fstream = new FileInputStream(indexResultFilename);
			// Get the object of DataInputStream
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			String strLine;

			// Read File Line By Line

			while ((strLine = br.readLine()) != null) {
				if (strLine.indexOf("DURATION") != -1) {
					strLine = strLine.replace("DURATION", duration);
				}
				if (strLine.indexOf("END_TIME") != -1) {
					strLine = strLine.replace("END_TIME", endTime.toString());
				}
				if (strLine.indexOf("TOTALTC") != -1) {
					strLine = strLine.replace("TOTALTC",
							String.valueOf(TOTALTC));
					System.out
							.println("TotalNumber:" + String.valueOf(TOTALTC));
				}
				if (strLine.indexOf("TOTALPASSTCITERATION") != -1) {
					TotalNumber = passNumber + failNumber + skipNumber;
					strLine = strLine.replace("TOTALPASSTCITERATION",
							String.valueOf(TotalNumber));
				}
				if (strLine.indexOf("TOTALPASSTC") != -1) {
					strLine = strLine.replace("TOTALPASSTC",
							String.valueOf(passNumber));
					System.out.println("passNumber:" + passNumber);
				}
				if (strLine.indexOf("TOTALFAILTC") != -1) {
					strLine = strLine.replace("TOTALFAILTC",
							String.valueOf(failNumber));
					System.out.println("failNumber:" + failNumber);
				}
				if (strLine.indexOf("TOTALSKIPTC") != -1) {
					int skippedNumber = TOTALTC - (failNumber + passNumber);
					strLine = strLine.replace("TOTALSKIPTC",
							String.valueOf(skippedNumber));
					System.out.println("skipNumber:" + skippedNumber);
				}
				if (strLine.indexOf("DEFECTREMOVALEFFICIENCY") != -1) {
					double totalnum = passNumber + failNumber + skipNumber;
					DefectRemovalEfficiency = round(
							((skipNumber / totalnum) * 360), 2);
					strLine = strLine.replace("DEFECTREMOVALEFFICIENCY",
							String.valueOf(DefectRemovalEfficiency));
				}
				if (strLine.indexOf("APPLICATION_URL") != -1) {
					app_url = DriverScript.OR.getProperty("loginURL");
					strLine = strLine.replace("APPLICATION_URL",
							String.valueOf(app_url));
				}
				if (strLine.indexOf("BROWSER") != -1) {
					browser = DriverScript.CONFIG.getProperty("testBrowser");
					strLine = strLine.replace("BROWSER",
							String.valueOf(browser));
				}
				if (strLine.indexOf("SIGN_OFF_STATUS") != -1) {
					int criteriaBlocker = Integer.valueOf(DriverScript.CONFIG
							.getProperty("ReleaseBlockerBugs"));
					int criteriaCritical = Integer.valueOf(DriverScript.CONFIG
							.getProperty("ReleaseCriticalBugs"));

					if (SeverityBlocker > criteriaBlocker
							|| SeverityCritical > criteriaCritical) {
						sign_off_status = "<td width=150 align=center colspan=6><FONT COLOR=#ff0000 FACE= Arial  SIZE=2.75<b>TestScope&nbsp;Criteria&nbsp;:&nbsp;Failed. Sign&nbsp;Off&nbsp;cannot&nbsp;be&nbsp;given.</b></td>\n";
					} else {
						sign_off_status = "<td width=150 align=center colspan=6<FONT COLOR=#008000 FACE= Arial  SIZE=2.75<b>TestScope&nbsp;Criteria&nbsp;:&nbsp;Passed. Sign&nbsp;Off&nbsp;can&nbsp;be&nbsp;given</b></td>\n";
					}
					strLine = strLine.replace("SIGN_OFF_STATUS",
							String.valueOf(sign_off_status));
				}
				if (strLine.indexOf("BUG_BLOCKER") != -1) {
					strLine = strLine.replace("BUG_BLOCKER",
							String.valueOf(SeverityBlocker));
				}
				if (strLine.indexOf("BUG_CRITICAL") != -1) {
					strLine = strLine.replace("BUG_CRITICAL",
							String.valueOf(SeverityCritical));
				}
				if (strLine.indexOf("BUG_MAJOR") != -1) {
					strLine = strLine.replace("BUG_MAJOR",
							String.valueOf(SeverityMajor));
				}
				if (strLine.indexOf("BUG_MINOR") != -1) {
					strLine = strLine.replace("BUG_MINOR",
							String.valueOf(SeverityMinor));
				}
				if (strLine.indexOf("CRITERIA") != -1) {
					testCriteria = "Blocker&nbsp;<=&nbsp;"
							+ DriverScript.CONFIG
									.getProperty("ReleaseBlockerBugs")
							+ "&nbsp;or&nbsp;Critical&nbsp;<=&nbsp;"
							+ DriverScript.CONFIG
									.getProperty("ReleaseCriticalBugs");
					strLine = strLine.replace("CRITERIA",
							String.valueOf(testCriteria));
				}
				if (strLine.indexOf("PROJECTTITLE") != -1) {
					strLine = strLine.replace("PROJECTTITLE",
							String.valueOf(projectTitle));
				}
				if (strLine.indexOf("PROJECTVERSION") != -1) {
					strLine = strLine.replace("PROJECTVERSION",
							String.valueOf(projectVersion));
				}
				if (strLine.indexOf("SCHEMA") != -1) {
					strLine = strLine.replace("SCHEMA", String.valueOf(Schema));
				}

				if (strLine.indexOf("TDID") != -1) {
					strLine = strLine.replace("TDID", String.valueOf(tdID));
				}
				buf.append(strLine);
			}

			// sending values to create pie chart
			double totalnum = passNumber + failNumber + skipNumber;
			
				DegreePass = (double) ((passNumber / totalnum) * 360);
				DegreeFail = (double) ((failNumber / totalnum) * 360);
				double skipped = TOTALTC - (failNumber + passNumber);
				DegreeSkip = (double) ((skipped / TOTALTC) * 360);
			if(totalnum!=0){
				DegreeNoissueStatus=0;
			}
			else{
				DegreeNoissueStatus=360;				
			}
			PieChartCreate.generatePieStatus();
			
			double totalSeverity=SeverityBlocker+SeverityCritical+SeverityMajor+SeverityMinor;
			if(totalSeverity!=0){
				DegreeBlocker=(double) ((SeverityBlocker/ totalSeverity) * 360);
				DegreeCritical=(double) ((SeverityCritical  / totalSeverity) * 360);
				DegreeMajor=(double) ((SeverityMajor / totalSeverity) * 360);
				DegreeMinor=(double) ((SeverityMinor / totalSeverity) * 360);
				DegreeNoissueSeverity=0;
			}
			else{
			/*	DegreeBlocker=0;
				DegreeCritical=0;
				DegreeMajor=0;
				DegreeMinor=0;*/
				DegreeNoissueSeverity=360;				
			}
			PieChartCreate.generatePieSeverity();
			
			// Close the input stream
			in.close();
			System.out.println(buf);
			FileOutputStream fos = new FileOutputStream(indexResultFilename);
			DataOutputStream output = new DataOutputStream(fos);
			output.writeBytes(buf.toString());
			fos.close();

		} catch (Exception e) {// Catch exception if any
			System.err.println("Error: " + e.getMessage());
		}
	}

	public static double round(double value, int places) {
		if (places < 0)
			throw new IllegalArgumentException();

		BigDecimal bd = new BigDecimal(value);
		bd = bd.setScale(places, RoundingMode.HALF_UP);
		return bd.doubleValue();
	}
}
