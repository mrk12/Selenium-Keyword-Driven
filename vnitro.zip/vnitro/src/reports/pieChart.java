package reports;

import java.awt.*;
import java.applet.*;

public class pieChart extends Applet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void paint(Graphics g) {
		int passValue = Integer.parseInt(getParameter("pass"));
		int failValue = Integer.parseInt(getParameter("fail"));
		int skipValue = Integer.parseInt(getParameter("skip"));
		setBackground(new Color(235,250,255));
		Color c1 = new Color(0, 150, 0);//green color
		Color c2 = new Color(200, 0, 0);//fail color
		Color c3 = new Color(255, 150, 150);//skip color
		Color c4 = new Color(0, 0, 0); //black color
		Color c5 = new Color(0, 50, 255); //dark blue color
		
		// outline for chart
		g.setColor(c5);
		g.drawRoundRect(20, 20, 750, 350, 25, 25);
		
		//creating piechart
		g.setColor(c4);
		g.drawArc(50, 50, 300, 300, 0, passValue);
		g.setColor(c1);
		g.fillArc(50, 50, 300, 300, 0, passValue);
		
		g.setColor(c4);
		g.drawArc(50, 50, 300, 300, passValue, failValue);
		g.setColor(c2);
		g.fillArc(50, 50, 300, 300, passValue, failValue);
		
		g.setColor(c4);
		g.drawArc(50, 50, 300, 300, failValue + passValue , skipValue);
		g.setColor(c3);
		g.fillArc(50, 50, 300, 300, failValue + passValue , skipValue);
		
		//creating indicators
		g.setColor(c4);
		g.setFont(new Font("Arial", Font.BOLD, 20));
	    g.drawString("TestCase Execution Summary",450,100);
		g.setColor(c1);
		g.fillRect(500, 150, 40, 30);
		g.setColor(c4);
		g.setFont(new Font("Arial", Font.PLAIN, 12));
		double passed=(passValue/(double)(passValue+failValue+skipValue))*100;
	    g.drawString("Passed ["+ReportUtil.round(passed,2)+"%]",570,170); 
		g.setColor(c2);
		g.fillRect(500, 200, 40, 30);
		g.setColor(c4);
		g.setFont(new Font("Arial", Font.PLAIN, 12));
		double failed=(failValue/(double)(passValue+failValue+skipValue))*100;
		g.drawString("Failed ["+ReportUtil.round(failed,2)+"%]",570,220);
		g.setColor(c3);
		g.fillRect(500, 250, 40, 30);
		g.setColor(c4);
		g.setFont(new Font("Arial", Font.PLAIN, 12));
		double skip=(skipValue/(double)(passValue+failValue+skipValue))*100;
		g.drawString("Skipped ["+ReportUtil.round(skip,2)+"%]",570,270);
		//g.setFont(new Font("Arial", Font.BOLD, 14));
		//double efficiency=((failValue/(double)(passValue+failValue)))*100;
		//g.drawString("Test Case Efficiency : "+ReportUtil.round(efficiency,2)+"%",500,370);
	}
}
